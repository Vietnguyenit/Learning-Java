package Connection_SQL_Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author giasutinhoc.vn
 */
public class JDBCStatementExample {

 // SQL Server JDBC connection string 
 static final String DB_URL = "jdbc:sqlserver://localhost;databaseName=CITIZENMANAGEMENT;user=ProVietNguyen;password=vietnguyen";

 public static void main(String[] args) {
   Connection conn = null;
   Statement stmt = null;
   try {
     //Open a connection
     System.out.println("Connecting to database...");
     conn = DriverManager.getConnection(DB_URL);

     //Execute a query
     System.out.println("Creating statement...");
     stmt = conn.createStatement();
     String sql = "INSERT INTO ADMINLG VALUES ('VIETHN111' ,1111 ), ('VIETDK111' ,1111 )"; 
     int rows = stmt.executeUpdate(sql);
     System.out.println("Rows impacted : " + rows);
     // Let us select all the records and display them.
     sql = "SELECT * FROM ADMINLG";
     System.out.println("HAHA");
     ResultSet rs = stmt.executeQuery(sql);
     //Extract data from result set
     System.out.println("HAHA1");
     while (rs.next()) {
       //Retrieve by column name
       String first = rs.getString("ADMINCODE");
       String last = rs.getString("PASSWORDAD");
       System.out.println("HAHA2");
       //Display values
       System.out.print(", First: " + first);
       System.out.println(", Last: " + last);
     }
     System.out.println("HAHA3");
     //Clean-up environment
     rs.close();
     stmt.close();
     conn.close();
   } catch (SQLException se) {
     //Handle errors for JDBC
     se.printStackTrace(); 
   } finally {
     //finally block used to close resources
     try {
       if (stmt != null) {
         stmt.close();
       }
     } catch (SQLException se2) {
     }// nothing we can do
     try {
       if (conn != null) {
         conn.close();
       }
     } catch (SQLException se) {
         se.printStackTrace();
     }//end finally try
    }//end try
   System.out.println("Done!");
 }
}