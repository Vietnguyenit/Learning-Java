package Connection_SQL_Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Oracle_JDBC {

	public static Connection getJDBCConnection() {
		final String Url = "jdbc:oracle:thin:@localhost:1521:NameDatabase";
		final String userName = "VietNguyen";
		final String Password = "111111" ;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			return DriverManager.getConnection(Url , userName , Password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
