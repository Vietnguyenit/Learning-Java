package Abstract_class;

// declare but no define and solve 
abstract public class TestAbstract { // class
	public String Name;
	abstract public double getAvgScore(); // function
}
