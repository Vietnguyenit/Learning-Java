//package T1;
//
//import java.util.ArrayList;
//import java.util.Scanner;
//
//public class Array_List {
//	
//	public static void main(String[] args) {
//		Scanner scanner = new Scanner(System.in);
//		ArrayList<Double> arrayList = new ArrayList<Double>();
//		System.out.print("Moi Nhap so phan tu :");
//		int a = scanner.nextInt();
//		int count = 0;
//		double sum = 0;
//		try {
//			for(int i = 0 ; i < a ; i++) {
//				count++;
//				System.out.println("Moi nhap phan tu thu "+ i);
//				double n = scanner.nextDouble();
//				arrayList.add(n);
//				sum = sum + n;
//			}
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		
//		for(int i = 0 ; i < a ; i++) {
//			double x = arrayList.get(i);
//			System.out.println(x);
//		}
//		System.out.println(sum/count);
//		System.out.println(arrayList);
//		
//		
//	}
//
//}
