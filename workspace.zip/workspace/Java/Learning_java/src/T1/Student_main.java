package T1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Student_main {
	
	public static void main(String[] args) {
		Student viet = new Student("viet" ,"","",9);
		
		ArrayList<Student> students = new ArrayList<Student>();
		students.add(viet);
//		students.add(new Student("viet", "56TH1", "DBA", 9));
//		students.add(new Student("viet", "56TH1", "DBA", 9));
//		students.add(new Student("viet", "56TH1", "DBA", 9));
//		students.add(new Student("viet", "56TH1", "DBA", 9));
		
		Student student = new Student();
		student.setName("vi");
		System.out.println(student.getName());
		student.StName = "haha" ;
		System.out.println(student.getName());
		System.out.println(students.get(0).getName());
		
//		for(Student x: students){
//			System.out.println(x.getName());
//            System.out.println(x.getStSubject());
//        }
//		
//		
//		
//		Student student = new Student();
//		student.setName("Viet");
//		System.out.println(student.getName());
//		for(int i = 0 ; i < students.size() ; i++) {
//		Student x = (Student)students.get(i);
//		System.out.println(x);
	}
		
		
}
