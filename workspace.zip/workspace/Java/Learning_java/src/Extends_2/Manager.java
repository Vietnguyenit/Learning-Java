package Extends_2;
import java.util.Scanner;

import Extends_1.Employee;

public class Manager extends Employee {
	public String MRole ;
	
	public String getMRole() {
		return MRole;
	}
	public void setMRole(String mRole) {
		MRole = mRole;
	}
	
	public Manager() {
		this("", 0, "", "", "");
	}
	
	public Manager(String n  , int a , String e , String p, String r) {
		this.Name = n;
		this.Age = a;
		this.Email = e;
		this.Password = p; 
		this.MRole = r;
	}

	Scanner scanner = new Scanner(System.in);
	private String Password;
	
	// Overriding on Parent Class if Parent Class "existed" (in case parent Class existed )
	// Can use super for access method of parent class 
	// must level public or more parent class 
	public void Input() {
		System.out.println("Enter Name: ");
		Name = scanner.nextLine();
		System.out.println("Enter Age: ");
		Age = scanner.nextInt();
		System.out.println("Enter Email :");
		Email = scanner.nextLine();
		scanner.nextLine();
		System.out.println("Enter Password :");
		super.setPassword(Password);
		Password = scanner.nextLine();
	}
	
	public void Output() {
		System.out.println("Name :" +Name);
		System.out.println("Age :"+ Age);
		System.out.println("Email :"+Email);
		System.out.println("Password :" +Password);
	}
}
