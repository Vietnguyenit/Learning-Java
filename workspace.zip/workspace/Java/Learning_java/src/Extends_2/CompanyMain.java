package Extends_2;

public class CompanyMain {

	public static void main(String[] args) {
		Manager manager = new Manager();
		manager.Input();
		manager.Output();
	}
}
