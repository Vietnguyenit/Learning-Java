package Re_Exc;

public class Register {

	private String Name;
	private String Sex;
	private String Address;
	private int Age;
	private String Email;
	private String Password;
	
	public Register () {
		this("", "", "", 0, "", "");
	}
	
	public Register(String name, String sex, String address, int age, String email, String password) {
		super();
		Name = name;
		Sex = sex;
		Address = address;
		Age = age;
		Email = email;
		Password = password;
	}
	
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
}
