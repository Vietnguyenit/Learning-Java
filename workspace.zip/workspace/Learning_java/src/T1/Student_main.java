package T1;

import java.util.ArrayList;

public class Student_main {
	public void main (String[] args) {
		ArrayList<Student> students = new ArrayList<Student>();
		
	}

}
