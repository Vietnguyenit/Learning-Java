package T1;

public class Student {
	private String StName;
	private String StClass;
	private String StSubject;
	private Double StScore;
	
	public Student() {
		this.StName = "";
		this.StClass = "";
		this.StSubject = "";
		this.StScore = 0.0;
	}
	
	public Student(String n , String c , String s , double sc) {
		this.StName = n;
		this.StClass = c;
		this.StSubject = s;
		this.StScore = sc;
	}
	public void setName(String n) {
		this.StName = n;
	}
	public String getName() {
		return StName;
	}
	
	public void setStClass(String c) {
		this.StClass = c;
	}
	public String getStClass() {
		return StClass;
	}
	
	public void setStSubject(String s) {
		this.StSubject = s;
	}
	public String getStSubject() {
		return StSubject;
	}
	
	public void setStScore(double sc) {
		this.StScore = sc;
	}
	public Double getStScore() {
		return StScore;
	}
}
