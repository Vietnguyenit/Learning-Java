package Num_Autobox;

public class NumberJava {
	
	public static void main(String[] args) {
		Integer integer = new Integer(22);
		int i = integer.intValue();
		System.out.println(i);
	}

}
