package quanlysinhvien;

public class Count 
{ 
    private int n; 

    public int getN() 
    { 
        return n; 
    } 

    public void setN(int n) 
    { 
        this.n = n; 
    } 

    public Count() 
    { 
        this(0); 
    } 

    public Count(int n) 
    { 
        this.n = n; 
    } 
}