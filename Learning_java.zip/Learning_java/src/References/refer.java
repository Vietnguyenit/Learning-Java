package References;

public class refer {
	public static int n = 10; 
	public static void test1() {
		n += 5;
	}
	public static void main(String[] args) {
		refer rs = new refer();
		int d = refer.n += 10;
		int r = rs.n += 4;
		System.out.println(r  + ""+ d);
	}
}
