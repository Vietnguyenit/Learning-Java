package Interface2;

public class Fish extends Animal {
	
	public Fish() {
		this("", "", "");
	}
	
	public Fish(String name, String age, String live) {
		super(name, age, live);
	}

	@Override
	public void Eat() {
		super.Eat();
		System.out.println("Banana");
	}
	
	@Override
	public void Drink() {
		super.Drink();
		System.out.println("Water");
	}
	
	@Override
	public void Vilocity() {
		super.Vilocity();
		System.out.println("10");
	}
}
