package Interface2;

public class Bird extends Animal{
	
	public Bird() {
		this("", "", "");
	}
	
	public Bird(String name, String age, String live) {
		super(name, age, live);
	}

	@Override
	public void Eat() {
		super.Eat();
		System.out.println("Rice");
	}
	
	@Override
	public void Drink() {
		super.Drink();
		System.out.println("Water");
	}
	
	@Override
	public void Vilocity() {
		super.Vilocity();
		System.out.println("50");
	}

}
