package Interface2;

// in interface just only container abstract method , constant , it's can't declare no abstract and normal function , variable
// and default functions is public abstract
public interface Animal_properties {
	abstract public void Drink();
	abstract public void Eat();
	abstract public void Vilocity();
}
