package Interface2;

public class Main {
	public static void Input() {
		
	}
	public static void main(String[] args) {
		Fish fish = new Fish();
		Animal animal = new Fish(); // parent class pointer subclass
		animal.setLive("fafa");
		System.out.println(animal.getLive());
		fish.setAge("10");
		fish.setLive("Pack");
		fish.setName("Gold");
		fish.Drink();
		fish.Eat();
		fish.Vilocity();
		System.out.println(fish.getAge() + fish.getLive() + fish.getName());
	}

}
