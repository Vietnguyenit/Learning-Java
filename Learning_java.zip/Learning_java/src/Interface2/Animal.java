package Interface2;

public abstract class Animal implements Animal_properties {
	
	private String name;
	private String age;
	private String live;
	
	public Animal(String name, String age, String live) {
		super();
		this.name = name;
		this.age = age;
		this.live = live;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getLive() {
		return live;
	}

	public void setLive(String live) {
		this.live = live;
	}

	@Override
	public void Eat() {
		System.out.println("Animal Eat : ");
	}
	
	@Override
	public void Drink() {
		System.out.println("Animal Drink :");
		
	}
	
	@Override
	public void Vilocity() {
		System.out.println("Vilocity :");
		
	}
	
}
