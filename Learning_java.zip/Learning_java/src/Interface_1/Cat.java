package Interface_1;

public class Cat extends Animal {
	private String Name ;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	@Override
	public void drink() {
		String food = "water";
		System.out.println("Cat :" + Name + " \ndrink :"+ food);
		//super.drink();
	}
	
	@Override
	public void eat() {
		super.eat();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	
	@Override
	public double getVilocity() {
		return super.getVilocity();
	}
}
