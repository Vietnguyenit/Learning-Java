package Interface_1;
//Interface for hint code it solve 
public class Animal_Pack {
	public static void main(String[] args) {
		Cat cat = new Cat();
		cat.setName("Tutu");
		cat.drink();
		cat.eat();
		cat.getVilocity();
	}
	
}
