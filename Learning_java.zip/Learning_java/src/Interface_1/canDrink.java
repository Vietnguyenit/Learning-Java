package Interface_1;

public interface canDrink {
	public void drink();
	public static final String Water = "water";
	final String Blood = "blood";
}
