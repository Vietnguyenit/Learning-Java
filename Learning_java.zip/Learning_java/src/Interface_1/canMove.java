package Interface_1;

public interface canMove {
	abstract public void run() ;
	abstract public void back();
	abstract public double getVilocity();
}
