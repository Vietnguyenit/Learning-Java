package Interface_1;

import java.util.Scanner;

abstract public class Animal implements canDrink , canEat , canMove { // must abstract
	
	Scanner scanner = new Scanner(System.in);
	public static double n;
	public static double vilocity = n;
	
	@Override
	public void run() {
		System.out.println("Animal Running .....");
	}
	
	@Override
	public void back() {
		System.out.println("It's go back ");
	}
	
	@Override
	public double getVilocity() {
		System.out.println("Enter Vilocity");
		n = scanner.nextDouble();
		System.out.println("Vilocity :"+n);
		return n;
	}
	
	@Override 
	public void eat() {
		System.out.println("It's Eating");
	}
	
	@Override
	public void drink() {
		System.out.println("It's Drink");
	}

}
