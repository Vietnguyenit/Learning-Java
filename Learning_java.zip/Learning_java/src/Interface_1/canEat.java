package Interface_1;

public interface canEat {
	public void eat();
}
