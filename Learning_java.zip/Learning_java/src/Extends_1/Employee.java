package Extends_1;

import java.util.Scanner;

public class Employee {
	public String Name;
	public Integer Age;
	protected String Email;
	private String Password;
	
	public Employee() {
		this("",0,"","");
	}
	public Employee(String name, Integer age, String email, String password) {
		super();
		Name = name;
		Age = age;
		Email = email;
		Password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Integer getAge() {
		return Age;
	}
	public void setAge(Integer age) {
		Age = age;
	}
	public String getEmail() {
		return Email;
	}
	public void setEamil(String eamil) {
		Email = eamil;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	Scanner scanner = new Scanner(System.in);
	
	// Parent Class Overriding
	public void Input() { 
	}
	
}
