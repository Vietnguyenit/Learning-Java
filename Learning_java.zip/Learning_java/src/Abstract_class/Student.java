package Abstract_class;

public class Student extends TestAbstract {

	public double scoMath = 6 , scoEnglish = 9 ;
	@Override
	public double getAvgScore() {
		return (scoEnglish + scoMath)/2 ;
	}
}
