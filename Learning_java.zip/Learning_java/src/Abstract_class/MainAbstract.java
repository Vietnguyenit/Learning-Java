package Abstract_class;

public class MainAbstract {
	public static void main(String[] args) {
//		TestAbstract testAbstract = null ;
//		testAbstract.getAvgScore();
		
		Student student = new Student();
		System.out.println(student.getAvgScore());
	}

}
