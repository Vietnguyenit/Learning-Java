package ThreadJava;

public class ThreadSys implements Runnable {
	public synchronized void run() {
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println(i);
			System.out.println(Thread.currentThread().getName()+"3");
		}
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(Thread.currentThread().getName()+"4");
	}
}
