package ThreadJava;

public class Thread_test2 extends Thread {
//	public Thread_test2(String s) {
//		super(s);
//	}
	
	//@Override
	public void run() {
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println(i);
		}
		try {
			Thread.sleep(5000);
			System.out.println("haha");
		} catch (Exception e) {
			System.out.println("Error " + e);
		}
	}
	
//	public static void main(String[] args) {
//		Thread_test2 thread = new Thread_test2();
//		thread.start();
//	}
}
