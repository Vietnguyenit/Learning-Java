package ThreadJava;

public class SysThread implements Runnable {
	public void run() {
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println(i);
			System.out.println(Thread.currentThread().getName()+"1");
		}
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(Thread.currentThread().getName()+"2");
	}
}
