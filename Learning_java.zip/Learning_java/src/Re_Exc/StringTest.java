package Re_Exc;

import java.util.ArrayList;
import java.util.Scanner;

public class StringTest {
	public static void main(String[] args) {
//		String string = "Nguyen Tien Viet";
//		
//		String Low = string.toUpperCase();
//		Low.trim();
//		string.split(string);
//		System.out.println(Low.matches(string));
//		System.out.println(Low.equals(string));
//		System.out.println(string);
		
		//Login
		/*
		Scanner scanner = new Scanner(System.in);
		String UserName = "";
		String Password = "";
		char ans = 0;
		do {
		System.out.print("User Name :");
		String user = scanner.nextLine();
		scanner.nextLine();
		System.out.println("\nPassword :");
		String pass = scanner.nextLine();
			if(UserName.equals(user) && Password.equals(pass)) {
				System.out.println("True");
				break;
			} else {
				System.out.println("False");
				System.out.println("Do you wana continue ?");
				ans = scanner.next().charAt(0);
			}
		}while(ans == 'y');
		
		check Eamil
		
		Pattern p = Pattern.compile("\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
		Matcher m = p.matcher("foobar@gmail.com");
		
		if (m.find())
		    System.out.println("Correct!");	
		*/
		
		//Register
		ArrayList<Register> registers = new ArrayList<Register>();
		Scanner scanner = new Scanner(System.in);
		String pattern = "0[0-9]{1,9}";
	//	String checkEmail = "\w+@\w+(\.\w){1,2}";
		char ans = 0;
		String name , sex , add , email , pass;
		Integer a;
		do {
			System.out.print("Moi Nhap Ten :");
			name = scanner.nextLine();
			scanner.nextLine();
			System.out.println("Moi Nhap gioi tinh :");
			sex = scanner.nextLine();
			System.out.println("Moi Nhap dia chi :");
			add = scanner.nextLine();
			System.out.println("Moi Nhap tuoi :");
			a = scanner.nextInt();
			System.out.println("Moi Nhap Email :");
			email = scanner.nextLine();
			scanner.nextLine();
			System.out.println("Moi Nhap mat khau :");
			pass = scanner.nextLine();
			System.out.println("Ban co muon tiep tuc ?(y)");
			ans = scanner.next().charAt(0);
			registers.add(new Register(name , sex , add , a , email , pass));
		} while (ans == 'y');
		for(Register r : registers) {
			System.out.println("Name"+r.getName());
			System.out.println("Sex"+r.getSex());
			System.out.println("Address"+r.getAddress());
			System.out.println("Age"+r.getAge());
			System.out.println("Email"+r.getEmail());
			System.out.println("Password"+r.getPassword());
		}
	}
}
