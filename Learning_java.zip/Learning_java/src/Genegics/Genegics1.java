package Genegics;

import java.awt.List;
import java.util.ArrayList;

public class Genegics1 { // tham so hoa du lieu
	List list = new List();
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public static void main(String[] args) {
		ArrayList arrayList = new ArrayList<>();
		ArrayList<Integer> arrayList1  = new ArrayList<Integer>();
		
		arrayList.add("Viet");
		arrayList.add(22);
		arrayList.add("TLU");
		arrayList.add("DK");

		//arrayList1.add("Viet"); error
		arrayList1.add(22);
		//arrayList1.add("TLU");
		//arrayList1.add("DK");

		
		String n = (String)arrayList.get(0);
		Integer a = (Integer)arrayList.get(1);
		String s = (String)arrayList.get(2);
		String h = (String)arrayList.get(3);
		System.out.println(n + " " + a + " " + s + " " + h);

	}
	
}
