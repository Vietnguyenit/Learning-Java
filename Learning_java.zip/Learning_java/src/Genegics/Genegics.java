package Genegics;

public class Genegics<T> { // can more < T , E , R ..>  must construct 
	private T t ;
	
	public void sett(T t) {
		this.t = t ;
	}
	public T gett() {
		return t ;
	}
	
	public static void main(String[] args) {
		Genegics<String>  sGenegics = new Genegics<String>();
		sGenegics.sett("String");
		String st = sGenegics.gett();
		System.out.println(st);
	}
}
