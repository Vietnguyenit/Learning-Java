package Genegics;

public class GenegicExtends<T extends Number> {
	private T nT ;
	public T getnT() {
		return nT;
	}
	public void setnT(T nT) {
		this.nT = nT;
	}
	public GenegicExtends(T n) {
		this.nT = n;
	}
	
	public double reciprocal() { // get nghich dao
		return 1/nT.doubleValue();
	}
	public double fraction() { // get binary
		return 1/nT.doubleValue() - nT.intValue();
	}
	public static void main(String[] args) {
		GenegicExtends<Integer> gi = new GenegicExtends<Integer>(10);
		Integer g1 = (int) gi.fraction();
		Integer g2 = (int)gi.reciprocal();
		System.out.println(g1 + " "+ g2);
		
		GenegicExtends<Double> gd = new GenegicExtends<Double>(10.3);
		Double g3 = (Double)gd.fraction();
		System.out.println(g3 + " "+ g2);
		
		GenegicExtends<Float> gf = new GenegicExtends<Float>(10f);
		Float g4 = (float)gf.reciprocal();
		Float g5 = (float)gf.fraction();
		
		System.out.println(g4 + " "+ g5);
	}

}
