package Enun_java;


public class Enum2 {
	public static enum Sex{
		Male("M" , "Male") , Female("F" , "Female");
		
		private String code , name ;
		Sex(String c , String n){
			this.code = c;
			this.name= n;
		}
		
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	}

	public static void main(String[] args) {
		Sex sex = Sex.Female;
		System.out.println(sex);
		sex.setCode("b");
		System.out.println(sex.getCode());
		
	}
}
