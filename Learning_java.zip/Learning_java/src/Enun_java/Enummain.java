package Enun_java;

import java.util.Scanner;

public class Enummain {
	 public static enum Transport{
		//car  , bike , train , boat , airplane ; // cac hang so liet ke
		car(28) , bike(5) , train(25) , airplane(25) ;
		 
		private int speed ;
		
		Transport(int s){
			this.speed = s;
		}
		
		public void setSpeed(int s) {
			this.speed = s;
		}
		
		public int getSpeed() {
			return speed;
		}
		
		public void Tra_compare() {
			Transport transport = null;
			transport = transport.train;
			if(transport == transport.train) {
				System.out.println(transport.bike.getSpeed());
			}else {
				System.out.println(transport.bike);
			}
		}
		
		public double Tra_switch(int x , int y) {
			switch (this) {
			case car:
				return x * y ;
			case bike :
				return x - y ;
			case train:
				return x / y ;
			case airplane :
				return x + y ;
			default:
				throw new Error("Unknow" + this); 
			}
		}
		
		public void Output() {
			System.out.println("Element of Enum");
			for(Transport t : Transport.values()) {
				System.out.println(t);
			}
			
			System.out.println("Array");
			Transport[] transports = Transport.values();
			
			for(Transport t : transports) {
				System.out.println(t);
			}
		}
	}
	
	public static void main(String[] args) {
		//Scanner scanner = new Scanner(System.in);
		Transport transport;
		transport = Transport.car;
		System.out.println(transport);
		transport.Tra_compare();
		double res  = Transport.car.Tra_switch(5, 6);
		System.out.println(res);
		transport.Output();
		transport.compareTo(transport.bike);
		transport.setSpeed(30);
		
		
	}
}
