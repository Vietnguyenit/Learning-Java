package T1;

import java.util.Scanner;

public class Control {
	Scanner scanner = new Scanner(System.in);
	Student student = new Student();
}
