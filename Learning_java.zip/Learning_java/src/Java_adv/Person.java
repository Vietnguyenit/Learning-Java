package Java_adv;

public class Person implements Comparable<Person>{ // for Compare
	private int code;
	private String name;
	private String howmtown;
	
	
	
	public Person() {
		super();
	}
	public Person(int code, String name, String howmtown) {
		super();
		this.code = code;
		this.name = name;
		this.howmtown = howmtown;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHowmtown() {
		return howmtown;
	}
	public void setHowmtown(String howmtown) {
		this.howmtown = howmtown;
	}
	
	@Override
	public int compareTo(Person p) {
		if(this.code > p.getCode() ) {
			return 1; // true tang
		}else if (this.code < p.getCode()) {
			return -1; // true giam 
		}else {
			return 0;
		}
	}
	
	public int compareTo(Person p1 , Person p2) {
		if(p1.getCode() > p2.getCode() ) {
			return 1; // true tang
		}else if (p1.getCode() < p2.getCode()) {
			return -1; // true giam 
		}else {
			return 0;
		}
	}
}
