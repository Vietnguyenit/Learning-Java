package Java_adv;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class CollectionFramew {

	public static void main(String[] args) {
		List list = new List();
		list.add("1");
		list.add("11");
		System.out.println(list.getItem(1));
		
		ArrayList list2 = new ArrayList();
		list2.add("3");
		list2.add(4);
		System.out.println(list2);
		
		LinkedList list3 = new LinkedList();
		list3.add("5");
		list3.add(6);
		System.out.println(list3);
		
		Set<String> setstring = new HashSet<String>();
		setstring.add("7");
		setstring.add("String");
		System.out.println(setstring);
		
		Map map = new HashMap<>();
		map.put("Viet", "8");
		System.out.println(map);
	}
}
