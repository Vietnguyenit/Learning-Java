package Java_adv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class Java_Collection {

	public static void main(String[] args) { // List allowed lap du lieu
		List<Person> alList = new ArrayList<Person>(); // save access 
		List<Person> vlList = new Vector<Person>(); // add edit delete
		List<Person> llList = new LinkedList<Person>(); // secure 
		
		alList.add(new Person(1 , "viet1" , "ck"));
		alList.add(new Person(3 , "viet2" , "dk"));
		alList.add(new Person(3 , "viet4" , "hk"));
		alList.add(new Person(2 , "viet1" , "ak"));
		alList.add(new Person(5 , "viet3" , "mk"));

		Collections.sort(alList); // so sanh dua tren ham compareTo da override
		
		for(Person person : alList) {	
			System.out.println(person.getCode());
		}
		
		
		Collections.sort(alList , new Comparator<Person>() { // an danh 
			@Override
			public int compare(Person o1, Person o2) {
				if(o1.getCode() > o2.getCode()) { //linh dong hon khong can dong den class person
					return -1 ;
				}else if (o1.getCode() < o2.getCode()) {
					return 1;
				}else {
					return 0;
				}
			}
		});
		
		
		for(Person person : alList) {	
			System.out.println(person.getCode());
		}
	}
	
	class myCompare implements Comparator<Person>{

		@Override
		public int compare(Person o1, Person o2) {
			if(o1.getCode() > o2.getCode()) { //linh dong hon khong can dong den class person
				return -1 ;
			}else if (o1.getCode() < o2.getCode()) {
				return 1;
			}else {
				return 0;
			}
		}
		
	}
}
