package Java_adv;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashset {
	public static void main(String[] args) {
		Set<String> set = new HashSet<>();
		
		set.add("A");
		set.add("D");
		set.add("C");
		set.add("B");
		set.add("B");
		
//		for(String s : set) {
//			System.out.println(s); // chi in ra 4 phan tu " A B C D " khong in ra phan tu trung 
// 		}
		
		Iterator<String> sIterator = set.iterator();
		while(sIterator.hasNext()) {
			String s = sIterator.next();// khong .next chay vo han
			if(s.equals("B")) {
				sIterator.remove();
			}
		}
		
		set.remove("D"); // chi remove theo doi tuong khong theo index vi khong co index
		//System.out.println(sIterator.next()); loi tran bo nho  
//		for(String s : set) {
//			System.out.println(s); // chi in ra 4 phan tu " A B C D " khong in ra phan tu trung 
// 		}
		
		Set<SetLib> set2 = new LinkedHashSet<SetLib>(); // hieu suat tot nhat nhung thu tu khong dc dam bao
		set2.add(new SetLib(1, "viet"));
		set2.add(new SetLib(2, "quan"));
		set2.add(new SetLib(3, "minh"));
		set2.add(new SetLib(4, "anh"));
		set2.add(new SetLib(5, "nam"));
		
//		for(SetLib setLib  : set2) {
//			System.out.println("Truoc :" + setLib.getCode());
//		}
		
		// neu khong co hashcode van in ra nen muon so sanh phai dung dong thoi ca equals va hashcode trong SET
		
		set2.remove(new SetLib(4, "tam")); 		
//		for(SetLib setLib  : set2) {
//			System.out.println("sau :" + setLib.getCode());
//		}
		
		
		// dung tuong tu nhu set trong linked
		// hieu suat khong bang hashset nhung sap xep tot hon
		Set<Integer> set3 = new TreeSet<>();  
		
		
		
		 
	}
}
