package Java_adv;
import java.util.Enumeration;
import java.util.Vector;

public class Vector_J {
	public static void main(String[] args) {
//		Vector<Integer> vIntegers = new Vector<Integer>();
//		vIntegers.add(6);
//		vIntegers.add(7);
//		vIntegers.add(8);
//		vIntegers.add(9);
//		vIntegers.add(6);
//		vIntegers.add(7);
//		vIntegers.add(8);
//		vIntegers.add(9);
//		vIntegers.add(6);
//		vIntegers.add(7);
//		System.out.println(vIntegers);
//		System.out.println(vIntegers.capacity());
//		vIntegers.addElement(4);
//		System.out.println(vIntegers);
//		System.out.println(vIntegers.capacity());
//		System.out.println(vIntegers.size());
		
		Vector v = new Vector(3 , 2);
		System.out.println("Size :" +v.size());
		System.out.println("Capacity :"+v.capacity());
		v.addElement(new Integer(5));
		v.addElement(new Double(8.2));
		v.addElement(new String("Viet"));

		v.addElement(new Integer(6));
		v.addElement(new Double(8.3));
		v.addElement(new String("Tien"));

		v.addElement(new Integer(7));
		v.addElement(new Double(8.4));
		v.addElement(new String("Nguyen"));
		
		System.out.println("Size :" +v.size());
		System.out.println("Capacity :"+v.capacity());
		
		System.out.println(v.firstElement());
		System.out.println(v.lastElement());
		
		Enumeration enumeration = v.elements();
		System.out.println("Element vector ");
		while(enumeration.hasMoreElements()) {
			System.out.print(enumeration.nextElement());
		}
			

	
		
	}

}
