package Java_adv;

import java.util.Enumeration;
import java.util.Hashtable;

public class Hash_table {

	public static void main(String[] args) {
		Hashtable hashtable = new Hashtable();
		hashtable.put("Viet", "VDK");
		hashtable.put("Quan", "VDK");
		hashtable.put("Viet1", 9);
		System.out.println(hashtable); // no print same key it is get last key
		System.out.println("size :"+hashtable.size());

		Enumeration enumeration;
		String string;
		int i;
		
		enumeration = hashtable.keys();
		while(enumeration.hasMoreElements()) {
			string = (String)enumeration.nextElement();
			System.out.println(string); // get keys 
			System.out.println(hashtable.get(string)); //get values
		}
	}
}
