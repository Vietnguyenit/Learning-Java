package Java_adv;

import java.util.Scanner;
import java.util.Stack;

public class Stack_J { // LIFO
	public static void showPush(Stack<Integer> s , int a) {
		s.push(new Integer(a));
		System.out.println("Push : "+ a );
		System.out.println("Stack :" + s);
	}
	
	public static void showpop(Stack s ) {
		System.out.println("Pop ");
		Integer a = (Integer)s.pop();
		System.out.println("Element were pop : "+a);
		System.out.println("Stack : "+s);
	}
	
	public static void main(String[] args) {
		Stack stack = new Stack();
		System.out.println(stack.empty());
		System.out.println("Stack" + stack);
		System.out.println("Push");
		System.out.println(stack.search(0));
		for(int i = 0 ; i < 5 ; i++) {
			showPush(stack, i);
		}
		System.out.println("Count 0 = "+stack.search(0));
		System.out.println("Position 3 :"+stack.elementAt(3));
		System.out.println("top:"+stack.peek());
		try {
			showpop(stack); 
		} catch (Exception e) {
		}
		
	}
}
