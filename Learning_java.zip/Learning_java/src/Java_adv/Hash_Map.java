package Java_adv;

import java.util.HashMap;
import java.util.Map;

public class Hash_Map {

	public static void main(String[] args) {
		Map map = new HashMap();
		map.put("Viet", "VNPT");
		map.put("Quan", "VDK");
		map.put("Minh", "VDK");
		System.out.println(map);
	}
}
