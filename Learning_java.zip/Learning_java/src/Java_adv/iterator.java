package Java_adv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class iterator {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		
		list.add(1);
		list.add(9);
		list.add(6);
		list.add(2);
		list.add(8);
		list.add(3);
		
		Collections.sort(list);
		
		Iterator<Integer> itr = list.iterator(); // xoa cac phan tu lap cua mang foreach k lam dc
		while(itr.hasNext()) { // kiem tra xem mang co rong k
			Integer i = itr.next(); // phai dung lop bao Integer dung int k the dc
			if(i.equals(1)) {
				itr.remove();
			}
		}
		
		for(Integer list2 : list) {
			System.out.println(list2);
		}



	}

}
