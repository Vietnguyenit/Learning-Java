#include<iostream>
#include<cmath>
using namespace std;
int main(){
	char tl ;
	do{
		int n;
		cout<<"Nhap 1 so :"; cin >> n;
//		int count = 0 ;
//		for(int s = 2 ; s < n ; s ++){
//			for(int i = 2 ; i <= n ; i ++ ){
//			if(s % i == 0){
//				count++;
//			}
//			}
//			if(count == 2 ){
//			cout<<"So Nguyen To :"<<s<<endl;
//			} else{
//				cout<<"No"<<endl;
//			}	
//		}

	bool KT = true;
	int count = 0;
	for(int tmp = 2 ; tmp < n ; tmp ++ ){
		KT = true;
		for(int i = 2 ; i <= sqrt(tmp) ; i++ ){
			if(tmp %  i == 0){
				KT = false;
				break;
			}
		}
		if(KT){
			count++;
			cout<<tmp<<" ";
		}
	}
	cout<<"Count :"<<count<<endl;
	cout<<"\nTL :";
	cin>>tl;
	}while(tl == 'y');
	return 0;
}
