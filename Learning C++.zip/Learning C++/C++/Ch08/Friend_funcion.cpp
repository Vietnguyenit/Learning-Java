// Friend function : it is can accress to the variable member level private 
// Friend Class

