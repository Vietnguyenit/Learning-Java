#include<iostream>
using namespace std;
const int MAX = 3;
int main(){
//	double a[] = {4 , 2, 9 , 5, 0 , 3 , 7};
//	double *p;
//	p = a; // now the pointer to a Array
//	
//	for(int  i = 0 ; i < 7 ; i++ ){
//		cout<<"Array a["<<i<<"] ="<<a[i]<<endl;
//	}
//	// use pointer the first position p pointer to a[0]
//	for(int  i = 0 ; i < 7 ; i++ ){
//		cout<<*(p+i)<<endl; 
//	}
//
//	//use a same address of pointer
//	for(int  i = 0 ; i < 7 ; i++ ){
//		cout<<*(a+i)<<endl;
//	}
//	

   int var[MAX] = {10, 100, 200};
   int *contro[MAX];
 
   for (int i = 0; i < MAX; i++)
   {
      contro[i] = &var[i]; // gan dia chi cua so nguyen.
   }
   for (int i = 0; i < MAX; i++)
   {
      cout << "Gia tri cua var[" << i << "] = ";
      cout << *contro[i] << endl;
   }
   
   
	int var[MAX] = {10, 100, 200};
	int *ptr;
	// let us have address of the last element in pointer.
	ptr = &var[MAX-1];
	for (int i = MAX; i > 0; i--)
	{
		cout << "Address of var[" << i << "] = ";
		cout << ptr << endl;
		cout << "Value of var[" << i << "] = ";
		cout << *ptr << endl;
		// point to the previous location
		ptr--;
	}	

//int var[MAX] = {10, 100, 200};
//int *ptr;
//// let us have address of the first element in pointer.
//ptr = var;
//int i = 0;
//cout<<ptr<<&var[MAX - 1];
//while ( ptr <= &var[MAX - 1] )
//{
//cout << "Address of var[" << i << "] = ";
//cout << ptr << endl;
//cout << "Value of var[" << i << "] = ";
//cout << *ptr << endl;
//// point to the previous location
//ptr++;
//i++;
//}
return 0;
}
