#ifndef DOCTOR_H // define only name
#define DOCTOR_H

#include <iostream>
#include <string>
#include <cstdlib>
#include "Employee.h"
using namespace std;

class Doctor : public Employee{
	private :
		double fee ;
		string speciality;
	public :
		//
		Doctor(); // ham khoi tao khong duoc ke thua lai
		Doctor(string name , int age ,double salary , double fee , string speciality);
		//
		void selfIntroduce();
		
		//
		void setFee(double f);
		double getFee();
		void setSpec(string s);
		string getSpec();
		
		// friend ostream& operator << (ostream& ots , Student& st);
		friend istream& operator >> (istream& ist , Doctor& d );
		friend ostream& operator << (ostream& ost , Doctor d );
};

#endif
