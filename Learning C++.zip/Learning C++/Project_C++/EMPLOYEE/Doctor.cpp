#include "Doctor.h"
#include "Employee.h"
using namespace std;


Doctor :: Doctor() : Employee() {
	fee = 1;
	speciality = "";
}

Doctor :: Doctor(string n , int a ,double sa , double f , string sp) : Employee( n , a , sa){
	fee = f;
	speciality = sp ;
}

void Doctor ::  selfIntroduce(){
	cout<<"\nIntroduce myself"<<endl;
	cout<<"\nName :"<<getName();
	cout<<"\nAge : "<<getAge();
	cout<<"\nFee :"<<getFee();
	cout<<"\nSpeciality :"<<getSpec();
	cout<<"\nSalary :"<<getSalary();
}

void Doctor :: setFee(double f){
	fee = f;
}
double Doctor :: getFee(){
	return fee;
}
void Doctor :: setSpec(string sp){
	speciality = sp ;
}
string Doctor :: getSpec(){
	return 	speciality; 
}

istream& operator >> (istream& ist , Doctor& id ){
	string speciality , name;
	double fee , salary;
	int age;
	cout<<"\n\nEnter Name :";
	ist>>name;
	id.setName(name);
	cout<<"\nEnter Age : ";
	ist>>age;
	id.setAge(age);
	cout<<"\nEnter Speciality : ";
	ist>>speciality;
	id.setSpec(speciality);
	cout<<"\nEnter Fee :";
	ist>>fee;
	id.setFee(fee);
	cout<<"\nEnter Salary :";
	ist>>salary;
	id.setSalary(salary);
	
	return ist;
}
ostream& operator << (ostream& ost , Doctor od ){
	
	ost<<"\nName :"<<od.getName();
	ost<<"\nAge : "<<od.getAge();
	ost<<"\nFee :"<<od.getFee();
	ost<<"\nSpeciality :"<<od.getSpec();
	ost<<"\nSalary :"<<od.getSalary();
	
	return ost;
}
