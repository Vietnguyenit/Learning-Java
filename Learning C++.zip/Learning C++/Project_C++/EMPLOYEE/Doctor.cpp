#include "Doctor.h"
using namespace std;


Doctor :: Doctor() : Employee() {
	fee = 1;
	speciatily = "";
}

Doctor :: Doctor(string n , int a ,double sa , double f , string sp) : Employee(string n , int a , doduble s){
	fee = f;
	speciatily = sp ;
}

void Doctor ::  selfIntroduce(){
	cout<<"\nName :";
	cout<<"\nAge : ";
	cout<<"\nFee :";
	cout<<"\nSpeciatily : ";
}

void Doctor :: setFee(double f){
	fee = f;
}
double Doctor :: getFee(){
	return fee;
}
void Doctor :: setSpec(string s){
	speciatily = sp ;
}
string Doctor :: getSpec(){
	return 	speciatily; 
}

istream& operator >> (istream& ist , Doctor& id ){
	string speciatily;
	double fee;
	cout<<"\nEnter Speciatily : ";
	ist>>speciatily;
	ie.setSpec(speciatily);
	cout<<"\Enter Fee :";
	ist>>fee;
	ie.setFee(fee);
	
	return ist;
}
ostream& operator << (ostream& ost , Doctor od ){
	
	ost<<"Name :"<<oe.getName();
	ost<<"Age :"<<oe.getAge();
	ost<<"Salary :"<<oe.getSalary();
	
	return ost;
}
