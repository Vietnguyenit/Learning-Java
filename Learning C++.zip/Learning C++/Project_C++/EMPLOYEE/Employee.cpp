#include "Employee.h"
using namespace std;

Employee :: Employee(){
	age = 1 ; 
	name = "";
	salary = 1;
}
Employee :: Employee(string n , int a){
	name = n;
	age = a;
}

Employee :: Employee(string n , int a, double s){
	name = n;
	age = a;
	salary = s;
}

void Employee :: selfIntroduce(){
	cout<<"\nName :";
	cout<<"\nAge : ";
}

void Employee :: setName(string n){
	name = n;
}

string Employee :: getName(){
	return name;
}

void Employee :: setAge(int a){
	age = a;
}

int Employee :: getAge(){
	return age;
}

void Employee :: setSalary(double s){
	salary = s;
}

double Employee :: getSalary(){
	return salary;
}

istream& operator >> (istream& ist , Employee& ie ){
	string name;
	int age;
	double salary;
	cout<<"\nEnter Name : ";
	ist>>name;
	ie.setName(name);
	cout<<"\Enter Age :";
	ist>>age;
	ie.setAge(age);
	cout<<"\nEnter Salary :";
	ist>>salary;
	ie.setSalary(salary);
	
	return ist;
}
ostream& operator << (ostream& ost , Employee oe ){
	
	ost<<"Name :"<<oe.getName();
	ost<<"Age :"<<oe.getAge();
	ost<<"Salary :"<<oe.getSalary();
	
	return ost;
}
