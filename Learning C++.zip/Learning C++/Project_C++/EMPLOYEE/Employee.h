#ifndef EMPLOYEE_H // define only name
#define EMPLOYEE_H

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

class Employee{
	private :
		string name;
		int age;
		double salary ;
	public :
		//
		Employee(); // ham khoi tao khong duoc ke thua lai
		Employee(string n , int a );
		Employee(string n , int a , double s);
		
		//
		void selfIntroduce();
		
		//
		void setName(string n);
		string getName();
		void setAge(int a);
		int getAge();
		void setSalary(double s);
		double getSalary();
		
		friend istream& operator >> (istream& ist , Employee& ie ); // can dung using namespace std
		friend ostream& operator << (ostream& ost , Employee oe );
};

#endif
