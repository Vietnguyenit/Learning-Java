#include <iostream>
#include "Doctor.cpp"
#include "Employee.cpp"
using namespace std;
int main(){
	
	Employee e;
//	e.setName("Viet");
//	e.setAge(22);
//	e.setSalary(1000);
//	e.selfIntroduce();

	cin>>e;
	cout<<e;
	
	Doctor d;
	cin>>d;
	cout<<d;
	
	e.selfIntroduce();
	d.selfIntroduce();
	
	return 0;
}
