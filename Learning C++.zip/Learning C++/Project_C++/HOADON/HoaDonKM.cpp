// Cai dat lop HoaDonKM
// Author: Le Nguyen Tuan Thanh
// Phien ban 1: 02/08/2017

#include "HoaDonKM.h"
using namespace std;

HoaDonKM::HoaDonKM():HoaDon(),giamGia(1000){}

HoaDonKM::HoaDonKM(int sl, double gc, double gg):HoaDon(sl,gc),giamGia(gg){}

double HoaDonKM :: thanhToan()
{
	cout<<getGiamGia()<<endl;
	return (tongTien() - getGiamGia());
}

void HoaDonKM::setGiamGia(double giamGiaMoi)
{
	giamGia = giamGiaMoi;
}
double HoaDonKM::getGiamGia()
{
	return giamGia;
}

//ostream& operator <<(ostream & os, HoaDonKM hdkm)
//{
//	os << hdkm.getSoLuong() << "-" << hdkm.getGiaCa() << "-" << hdkm.getGiamGia();
//	return os;
//}


