/*
 * Chuong trinh minh hoa Ke thua voi hai lop HoaDon va HoaDonKM
 * Author: Le Nguyen Tuan Thanh
 * Phien ban 1: 02/08/2017
 */
 
#include<iostream>

#include "HoaDon.cpp"
#include "HoaDonKM.cpp"

using namespace std;

int main()
{
//	HoaDon hd1(2, 2000);
//	HoaDonKM hdkm1(2, 2000, 1000);
	
//	HoaDon 
//	cout << hd1 << endl;
//	cout << hdkm1 << endl;
//	
//	cout << hd1.tongTien() << endl;
//	cout << hdkm1.thanhToan() << endl;
	
	HoaDon hd;
	HoaDonKM hdkm;
	hd.setGiaCa(9);
	hd.setSoLuong(8);
	hdkm.setSoLuong(15);
	hdkm.setGiaCa(10);
	hdkm.setGiamGia(10);
	cout<<"So Luong : ="<<hdkm.getSoLuong()<<endl;
	cout<<"Gia ca "<<hdkm.getGiaCa()<<endl;
	cout<<"KM = "<<hdkm.getGiamGia()<<endl;
	cout<<"Tong tien :"<<hd.tongTien()<<endl;
	cout<<"Phai tra : "<<hdkm.thanhToan();
	
	return 0;
}

