#ifndef HOADON_H // define only name
#define HOADON_H

#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

class HoaDon{
	private :
		int soLuong ;
		double giaCa;
	public :
		//
		HoaDon(); // ham khoi tao khong duoc ke thua lai
		HoaDon(int sl , double gc);
		
		//
		double tongTien();
		
		//
		void setSoLuong(int sl);
		int getSoLuong();
		void setGiaCa(double gc);
		double getGiaCa();
		
		// friend ostream& operator << (ostream& ots , Student& st);
		friend istream& operator >> (istream& ist , HoaDon& h );
		friend ostream& operator << (ostream& ost , HoaDon h );
};

#endif
