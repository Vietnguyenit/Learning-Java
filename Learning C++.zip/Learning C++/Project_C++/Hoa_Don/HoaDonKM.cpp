#include<iostream>
#include "HoaDonKM.h"
using namespace std;

HoaDonKM :: HoaDonKM():HoaDon() , giamGia(1){
//	giaCa = 1 ;
//	soLuong = 10 ;
}

HoaDonKM :: HoaDonKM(int sl , double gc , double gg ):HoaDon(sl , gc) , giamGia(gg){
//	giaCa = 1 ;
//	soLuong = 10 ;
}
//
//HoaDonKM :: HoaDonKM(int sl , double gc , double gg){
//	giaCa = gc;
//	soLuong = sl;
//	giamGia = gg;
//}

double HoaDonKM :: thanhToan(){
	return (tongTien() - getGiamGia());
}

void HoaDonKM :: setGiamGia(double gg){
	giamGia = gg;
}
double HoaDonKM :: getGiamGia(){
	return giamGia;
}

istream& operator >> (istream& ist, HoaDonKM & h){
	int gg;
	cout<<"Nhap gia giam : ";
	ist>>gg;
	h.setGiamGia(gg);
	return ist;
}
ostream& operator << (ostream& ost , HoaDonKM h ){
	ost<<"Gia Gia :"<< h.getGiamGia();
	return ost;
}
