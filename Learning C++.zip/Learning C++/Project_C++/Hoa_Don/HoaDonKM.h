#ifndef HOADONKM_H // define only name
#define HOADONKM_H

#include <iostream>
#include <string>
#include <cstdlib>
#include "HoaDon.h"
using namespace std;

class HoaDonKM : public HoaDon{
	private :
		double giamGia;
	public :
		//
		HoaDonKM(); // ham khoi tao khong duoc ke thua lai
		HoaDonKM(int sl , double gc, double gg);
		
		//
		double thanhToan();
		
		//
		void setGiamGia(double gg);
		double getGiamGia();
		
		//
		friend istream& operator >> (istream& ist , HoaDonKM & h);
		friend ostream& operator << (ostream& ost , HoaDonKM h);
};

#endif
