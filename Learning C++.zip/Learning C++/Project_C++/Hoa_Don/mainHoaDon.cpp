#include<iostream>
#include "HoaDon.cpp"
#include "HoaDonKM.cpp"
using namespace std;

int main(){	
//	HoaDon hd(10 , 5.1);
//	HoaDonKM hdkm(10 , 5.3 , 10.1);

	HoaDon hd;
	HoaDonKM hdkm;
//	hd.setGiaCa(9);
//	hd.setSoLuong(8);
	hdkm.setSoLuong(15);
	hdkm.setGiaCa(10);
	hdkm.setGiamGia(10);
	cout<<"So Luong : ="<<hdkm.getSoLuong()<<endl;
	cout<<"Gia ca "<<hdkm.getGiaCa()<<endl;
	cout<<"KM = "<<hdkm.getGiamGia()<<endl;
	cout<<"Tong tien :"<<hdkm.tongTien()<<endl;
	cout<<"Phai tra : "<<hdkm.thanhToan();
	
	return 0;
}

