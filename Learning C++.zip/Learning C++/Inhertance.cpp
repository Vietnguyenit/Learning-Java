/*
ogain define : must together the variable
overloadding : can't together the variable
*/
#
