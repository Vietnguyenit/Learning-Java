/*
ogain define : must together the variable
overloadding : can't together the variable
use protected for extends only for subclass
a subclass can extends from many parent class 
*/
#
