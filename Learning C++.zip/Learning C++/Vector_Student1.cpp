#include<iostream>
#include<vector>
#include<iomanip>
using namespace std;

//dinh nghia cau truc
struct Student {
	string Code;
	string Name;
	string Class_St;
	double Score;
};
void NewStudent();
void DeleteStudent();
void SearchStudent();
void ShowListClass();
void ShowAllStudent();

int main(){
	vector<Student> Vtst; 
	int choose;
	do{
		system("CLS");
		cout<<"1.New Student "<<endl;
		cout<<"2.Delete Student "<<endl;
		cout<<"3.Search with code "<<endl;
		cout<<"4.Show list with class"<<endl;
		cout<<"5.Show all Student "<<endl;
		cout<<"6.Exit"<<endl;
		cout<<"Choose (1 - 6)"<<endl;
		cin>>choose;
	}while(choose < 1 || choose > 6);	
	switch (choose){
		case 1:
			int n;
			cout<<"How many numbers of Student you wana ? :";
			cin>>n;
			Input(Vtst , n);
			cout<<"Done"<<endl;
			system("PAUSE");
			break;
		case 2:
			Output(Vtst , n);
			break;
		case 3:
			
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		default :
			break;
	}
	return 0;
}

void DeleteStudent(string code , vector<Student> &st){
	
	// kiem tra xem codo co trung k { luu lai vi tri }
	
	// st.erase(st.begin() + vt )
}
void SearchStudent(){
	// lay tat ca trong danh sach 
	// kiem tra code nhap vao
	// luu lai vi tri
	//inra ket qua vio vi tri
	int tmpi;
	string code;
	cout<<"Enter the code :";
	cin>>code;
	for(int i = 0 ; i < vtSt.size(); i++ ){
		if(code == vtSt[i].Code){
			tmpi = i;
			cout<<"i";
			break;
		}else{
			cout<<"Not found"<<endl;
		}
	}
}
void Input(vector<Student> &Vtst, int size);
void Input(vector<Student> &Vtst , int size){
	Student st;
	for(int i = 0 ; i < size ; i++){
		cout<<"Enter "<<size+1<<" Student "<<endl;
		cout<<"\nEnter the code :";
		getline(cin , st.Code);
		cout<<"\nEnter the Name :";
		getline(cin , st.Name);
		cout<<"\nEnter the class :";
		getline(cin , st.Class_St);
		cout<<"\nEnter the Score :";
		cin>>st.Score;
		Vtst.push_back(st);		
	}
}
void Output(vector<Student> Vtst);
void Output(Student st , int size){
	for(int i = 0 ; i < size ; i++){
		cout<<"\nCode :"<<st.Code;
		cout<<"\nName :"<<st.Name;
		cout<<"\nClass :"<<st.Class_St;
		cout<<"\nScore :"<<st.Score;
	}
}

void ShowListClass(){
}
void ShowAllStudent(vector<Student> stList){
	//for()
}
