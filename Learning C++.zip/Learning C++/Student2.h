class Student2{
	public :
		int a ;
};
