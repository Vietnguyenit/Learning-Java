/*
nhap vao 2 chuoi roi sa sanh 2 chuoi xem co doan nao trung k

string s1 , s3 ;
int dem  = 0 ; int pos = -1 ;

do{
pos = str1.find(str2 , pos+1)
}

*/

#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

int main(){
	
	string str1 , str2;
	int count = 0 , pos = -1  , tmp = -1;
	cout<<"Nhap chuoi thu nhat : ";
	getline(cin , str1);
	
	cout<<"Nhap chuoi thu hai : ";
	getline(cin , str2);
	do{
		pos = -1 ; 
		pos = str1.find(str2, tmp+1);
		tmp = pos;
		if(tmp > -1){
			count ++;
		}
	}while(pos != -1);
	
	cout<<"Count : " <<count;
	
	return 0;
}
