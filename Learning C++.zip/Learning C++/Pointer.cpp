#include<iostream>
using namespace std;
int main(){
	int a = 5 ; // declare function pointer type but use & , declare & use nommal
	int *pt;
	pt = &a;  // with array don't need & if it is difine stay first else use
	cout<<"a"<<a;
	cout<<"pt"<<pt<<endl;
	cout<<"*pt"<<*pt; // must
	return 0;
}
