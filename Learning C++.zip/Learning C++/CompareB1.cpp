#include<iostream>
using namespace std;
int compare(int a , int b , int c);
int a , b , c ;
int compare(int a , int b , int c ){
	int tmpmax, max;
	if(a > b){
		tmpmax = a;
	}else{
		tmpmax = b ;
	}
	if(tmpmax > c){
		max = tmpmax;
	}
	else{
		max = c ;
	}
	cout<<max;
	return max;
}
int main(){
	cout<<"Nhap 3 so nguyen"<<endl;
	cout<<"a:";
	cin>>a;
	cout<<"b:";
	cin>>b;
	cout<<"c:";
	cin>>c;
	compare(a , b , c);
	return 0;
}
