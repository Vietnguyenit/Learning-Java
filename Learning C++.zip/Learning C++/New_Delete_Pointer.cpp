#include<iostream>
#include<cassert>
using namespace std;

void test(int a , double b);
void test(double a , double b, double c);
void test(int a , double b){
	cout<<a <<" "<<b<<endl;
}

void test(double a , double b, double c){
	cout<<a <<" "<<b<<" "<<c<<endl;
}
int main(){
int a;
try{
	cout<<"Nhap:"; cin >>a;
	assert(a> 6); // try catch cung chiu
	cout<<"viet";
}catch(string e){
	cout<<"haha";
}
test(3, 9.3);
test(5 , 9 , 3);
return 0;
}
