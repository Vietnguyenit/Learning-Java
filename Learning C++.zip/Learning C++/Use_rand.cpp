#include<iostream>
#include<cstdlib>
using namespace std;
void SortArray(int arr[] , int size);
int main(){
	int size;
	cout<<"Enter the numbers of array :";
	cin>>size;
	int arr[size];
	cout<<"Enter the Element :"<<endl;
	for(int i = 0 ; i <size ; i++ ){
//		cout<<"a["<<i<<"] = ";
//		cin>>arr[i];
		arr[i] = rand() % 10;
	}	
	
	SortArray(arr , size);
	return 0;
}

void SortArray(int arr[] , int size) {
	cout<<"Array Before sort : "<<endl;
	for(int i = 0 ; i < size ; i++){
		cout<<"a["<<i<<"] = "<<arr[i]<<" ";
	}
	 
	int tmp;
	for(int i = 0 ; i < size ; i++){
		for(int j = i + 1 ; j < size ; j++){
			if(arr[i] > arr[j]){
				tmp = arr[i];
				arr[i] = arr[j];
				arr[j] = tmp;
			}
		}
	}
	
	cout<<"\nArray Sorted : ";
	for(int i = 0 ; i < size ; i++){
		cout<<"a["<<i<<"] = "<<arr[i]<<" ";
	}
}

