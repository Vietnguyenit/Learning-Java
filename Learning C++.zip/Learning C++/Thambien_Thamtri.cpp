/*
1.hien thi tat ca sinh vien
2.hien thi sinh vien khi nhap id tu ban phim
3.hien thi thong tin sinh vien co diem toan max min
4.hien thi thong tin sinh vien co diem tieng anh max min
5.hien thi thong tin sinh vien co dien trung binh max min
*/
#include<iostream>
#include<cstdlib>
#include<iomanip>
using namespace std;

struct Student {
	int Code;
	string Name ;
	double Mathsco , Englishsco ;
	double avgScore;
};

double GetAvg(double m , double e);
double GetAvg(double m , double e){
	return (m + e) /2 ;
}

Student arrSt[100];
int index = 0;

void NewStudent();
void NewStudent(){
	int n , count = 0;
	cout<<"Enter the number Student :";
	cin>>n;	
 LOOP : for(int i = 0 ; i < n ; i ++){
 		count = count++;
		Student tmpSt;
		cout<<"Enter the the student :"<<i+1<<endl;
		cout<<"Enter the Code :";
		cin>>tmpSt.Code;
		for(int i = 0 ; i < index ; i ++){	
				if(tmpSt.Code == arrSt[i].Code){
					cout<<"Code existed , plase enter again ...  "<<endl;
				}	
		}
		cin.ignore();
		cout<<"Enter the Name :";
		getline(cin , tmpSt.Name);
		cout<<"Enter Math score :";
		cin>>tmpSt.Mathsco;
		cout<<"Enter English score :";
		cin>>tmpSt.Englishsco;
		tmpSt.avgScore = GetAvg(tmpSt.Mathsco , tmpSt.Englishsco);
		arrSt[index] = tmpSt;
		index++;
	}
}

void OutputStudent();

void OutputStudent(){
	cout<<setw(5)<<"Ma"<<setw(10)<<"Name"<<setw(15)<<"Math-Score"<<setw(20)<<"English-Score"<<setw(25)<<"Avg-score"<<endl; 
	for(int i = 0 ; i < index ; i++){
			cout<<setw(5)<<arrSt[i].Code<<setw(10)<<arrSt[i].Name<<setw(13)<<arrSt[i].Mathsco<<setw(18)<<arrSt[i].Englishsco<<setw(25)<<arrSt[i].avgScore<<endl; 
	}
}

void SortList();
void SortList(){
	int tmp;
	for(int i = 0 ; i < index ; i ++){
		for(int j = i+1 ; j< index ; j++){
			if(arrSt[i].avgScore >  arrSt[j].avgScore){
				tmp = arrSt[i].Code;
				arrSt[i].Code = arrSt[j].Code;
				arrSt[j].Code = arrSt[i].Code; 
			}
		}
	}
	OutputStudent();
}

void DeleteStudent();

//	for(i=0; i<size; i++)
//	{
//		if(arr[i]==del)
//		{
//			for(int j=i; j<(size-1); j++)
//			{
//				arr[j]=arr[j+1];
//			}
//			count++;
//			break;
//		}
//	}

void DeleteStudent(){
		int code;
		cout<<"Delete a Student with Code"<<endl;
		cout<<"Enter the code :"<<endl;
		cin>>code;
		for(int i = 0 ; i < index  ; i ++){
			if(arrSt[i].Code == code){
				for(int j = i ; j < (index); j++){		
					arrSt[j].Code = arrSt[j+1].Code;
					arrSt[j].Name = arrSt[j+1].Name;
					arrSt[j].Mathsco = arrSt[j+1].Mathsco;
					arrSt[j].Englishsco = arrSt[j+1].Englishsco;
					arrSt[j].avgScore = arrSt[j+1].avgScore;	
				}
				break;
			}
		}
}

void SeachStudent();
void SeachStudent(){
		int code;
		cout<<"Search a Student with Code"<<endl;
		cout<<"Enter the code :"<<endl;
		cin>>code;
		for(int i = 0 ; i < index ; i ++){
			if(code == arrSt[i].Code){
				cout<<"Information Of Student "<<endl;
				cout<<"Code :"<<arrSt[i].Code<<endl;
				cout<<"Name :"<<arrSt[i].Name<<endl;
				cout<<"Avg Score :"<<arrSt[i].avgScore<<endl;
			}
		}
}
void EditStudent();
void EditStudent(){
		int code;
		cout<<"Edit a Student with Code"<<endl;
		cout<<"Enter the code :"<<endl;
		cin>>code;
		for(int i = 0 ; i < index ; i ++){
			if(code == arrSt[i].Code){
				
			}
		}
}

void M2Math();
void M2English();
void M2EnglishMath();

// Tinh diem max va min cua mon toan 
void M2Math(){
	int max=0 , min= arrSt[0].Mathsco , tmpma , tmpmi;
	for(int i = 0 ; i < index ; i++){
		if(max <= arrSt[i].Mathsco){
 			max = arrSt[i].Mathsco;
 			tmpma  = i;
	 	}
	 	
		if( min > arrSt[i].Mathsco ){
 			min = arrSt[i].Mathsco;
			tmpmi  = i;
	 	}
	}
	OutputStudent();
	
	cout<<"Information Of Student Max Math "<<endl;
	cout<<"Code :"<<arrSt[tmpma].Code<<endl;
	cout<<"Name :"<<arrSt[tmpma].Name<<endl;
	cout<<"Math :"<<arrSt[tmpma].Mathsco<<endl;
	cout<<"English :"<<arrSt[tmpma].Englishsco<<endl;
	cout<<"Avg Score :"<<arrSt[tmpma].avgScore<<endl;
	
	cout<<"Information Of Student Min Math "<<endl;
	cout<<"Code :"<<arrSt[tmpmi].Code<<endl;
	cout<<"Name :"<<arrSt[tmpmi].Name<<endl;
	cout<<"Math :"<<arrSt[tmpmi].Mathsco<<endl;
	cout<<"English :"<<arrSt[tmpmi].Englishsco<<endl;
	cout<<"Avg Score :"<<arrSt[tmpmi].avgScore<<endl;
}

//void Search_MaxMin(){
//	string s;
//	cout<<"Enter the name : ";
//	getline(cin , s);
//	int max=0 , min= 0 , tmpma , tmpmi;
//	for(int i = 0 ; i < index ; i++){
//		if(max <= arrSt[i].s){
// 			max = arrSt[i].s;
// 			tmpma  = i;
//	 	}
//	}
//	
//	OutputStudent();
//	
//	cout<<"Information Student Max of: "<<s<<endl;
//	cout<<"Code :"<<arrSt[tmpma].Code<<endl;
//	cout<<"Name :"<<arrSt[tmpma].Name<<endl;
//	cout<<"Math :"<<arrSt[tmpma].Mathsco<<endl;
//	cout<<"English :"<<arrSt[tmpma].Englishsco<<endl;
//	cout<<"Avg Score :"<<arrSt[tmpma].avgScore<<endl;
//}

//tinh diem max min cua mon tieng anh
void M2English(){
	// Search_MaxMin();
	int max=0 , min= arrSt[0].Englishsco , tmpma , tmpmi;
	for(int i = 0 ; i < index ; i++){
		if(max <= arrSt[i].Englishsco){
 			max = arrSt[i].Englishsco;
 			tmpma  = i;
	 	}
	}
	
	for(int i = 0 ; i < index ; i++){ 	
		if( min > arrSt[i].Englishsco ){
 			min = arrSt[i].Englishsco;
			tmpmi  = i;
	 	}
	}

	OutputStudent();
	
	cout<<"Information Of Student Max English "<<endl;
	cout<<"Code :"<<arrSt[tmpma].Code<<endl;
	cout<<"Name :"<<arrSt[tmpma].Name<<endl;
	cout<<"Math :"<<arrSt[tmpma].Mathsco<<endl;
	cout<<"English :"<<arrSt[tmpma].Englishsco<<endl;
	cout<<"Avg Score :"<<arrSt[tmpma].avgScore<<endl;
	
	cout<<"Information Of Student Min English "<<endl;
	cout<<"Code :"<<arrSt[tmpmi].Code<<endl;
	cout<<"Name :"<<arrSt[tmpmi].Name<<endl;
	cout<<"Math :"<<arrSt[tmpmi].Mathsco<<endl;
	cout<<"English :"<<arrSt[tmpmi].Englishsco<<endl;
	cout<<"Avg Score :"<<arrSt[tmpmi].avgScore<<endl;
}
void M2EnglishMath(){
		int max=0 , min= arrSt[0].avgScore , tmpma , tmpmi;
	for(int i = 0 ; i < index ; i++){
		if(max <= arrSt[i].avgScore){
 			max = arrSt[i].avgScore;
 			tmpma  = i;
	 	}
	 	
		if( min > arrSt[i].avgScore ){
 			min = arrSt[i].avgScore;
			tmpmi  = i;
	 	}
	}
	OutputStudent();
	
	cout<<"Information Of Student Max Both "<<endl;
	cout<<"Code :"<<arrSt[tmpma].Code<<endl;
	cout<<"Name :"<<arrSt[tmpma].Name<<endl;
	cout<<"Math :"<<arrSt[tmpma].Mathsco<<endl;
	cout<<"English :"<<arrSt[tmpma].Englishsco<<endl;
	cout<<"Avg Score :"<<arrSt[tmpma].avgScore<<endl;
	
	cout<<"Information Of Student Min Both"<<endl;
	cout<<"Code :"<<arrSt[tmpmi].Code<<endl;
	cout<<"Name :"<<arrSt[tmpmi].Name<<endl;
	cout<<"Math :"<<arrSt[tmpmi].Mathsco<<endl;
	cout<<"English :"<<arrSt[tmpmi].Englishsco<<endl;
	cout<<"Avg Score :"<<arrSt[tmpmi].avgScore<<endl;
}

int main(){
	int ans;
	try{
	while(true){
		//	LOOP : 
		do
		{
			system("CLS");
			cout<<"The program for Get Avg Score of Student"<<endl;
			cout<<"1. New Student"<<endl;
			cout<<"2. Show information of Student "<<endl;
			cout<<"3. Delete a student with code "<<endl;
			cout<<"4. Search a student with code "<<endl;
			cout<<"5. Edit a student with code"<<endl;
			cout<<"6. Sort List of Student "<<endl;
			cout<<"7. Find the student have Max Min English Score:"<<endl;
			cout<<"8. Find the student have Max Min Math Score:"<<endl;
			cout<<"9. Find the student have Max Min Avg Score:"<<endl;
			cout<<"10. Exit"<<endl;
			cout<<"Chose 1 - 10 :";
			cin>>ans;
		}while(ans < 1 || ans > 10);
		switch(ans){
			case 1 :
				NewStudent();
				system("PAUSE");
				break;
			case 2 :
				OutputStudent();
				system("PAUSE");
				break;
			case 3 :
				DeleteStudent();
				system("PAUSE");
				break;
			case 4 :
				SeachStudent();
				system("PAUSE");
				break;
			case 5 :
				EditStudent();
				system("PAUSE");
				break;
			case 6:
				SortList();
				system("PAUSE");
				break;
			case 7:
				M2English();
				system("PAUSE");
				break;
			case 8:
				M2Math();
				system("PAUSE");
				break;
			case 9:	
				M2EnglishMath();
				system("PAUSE");
				break;
			case 10 :
				exit(1);
				break;
			default:
			//	goto LOOP;
				break;
		}
	}}
	catch (string e) {  
	   cout <<e;  
	}	  
	return 0;	
}


/* C++ Program - Delete Element from Array */
		
//#include<iostream>
//using namespace std;
//int main()
//{
//	int arr[50], size, i, del, count=0;
//	cout<<"Enter array size : ";
//	cin>>size;
//	cout<<"Enter array elements : ";
//	for(i=0; i<size; i++)
//	{
//		cin>>arr[i];
//	}
//	cout<<"Enter element to be delete : ";
//	cin>>del;
//	for(i=0; i<size; i++)
//	{
//		if(arr[i]==del)
//		{
//			for(int j=i; j<(size-1); j++)
//			{
//				arr[j]=arr[j+1];
//			}
//			count++;
//			break;
//		}
//	}
//	if(count==0)
//	{
//		cout<<"Element not found..!!";
//	}
//	else
//	{
//		cout<<"Element deleted successfully..!!\n";
//		cout<<"Now the new array is :\n";
//		for(i=0; i<(size-1); i++)
//		{
//			cout<<arr[i]<<" ";
//		}
//	}
//}
