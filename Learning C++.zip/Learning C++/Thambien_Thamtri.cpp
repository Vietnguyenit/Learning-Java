#include<iostream>
#include<cstdlib>
#include<iomanip>
using namespace std;

struct Student {
	int Code;
	string Name ;
	double Mathsco , Englishsco ;
	double avgScore;
};

double GetAvg(double m , double e);
double GetAvg(double m , double e){
	return (m + e) /2 ;
}

Student arrSt[100];
int index = 0;

void NewStudent();
void NewStudent(){
	int n , count = 0;
	cout<<"Enter the number Student :";
	cin>>n;	
 LOOP : for(int i = 0 ; i < n ; i ++){
 		count = count++;
		Student tmpSt;
		cout<<"Enter the Code :";
		cin>>tmpSt.Code;
		for(int i = 0 ; i < index ; i ++){	
				if(tmpSt.Code == arrSt[i].Code){
					cout<<"Code existed , plase enter again ...  "<<endl;
				}	
		}
		cin.ignore();
		cout<<"Enter the Name :";
		getline(cin , tmpSt.Name);
		cout<<"Enter Math score :";
		cin>>tmpSt.Mathsco;
		cout<<"Enter English score :";
		cin>>tmpSt.Englishsco;
		tmpSt.avgScore = GetAvg(tmpSt.Mathsco , tmpSt.Englishsco);
		arrSt[index] = tmpSt;
		index++;
	}
}

void OutputStudent();
void OutputStudent(){
	cout<<setw(5)<<"Ma"<<setw(10)<<"Name"<<setw(15)<<"Math-Score"<<setw(20)<<"English-Score"<<setw(25)<<"Avg-score"<<endl; 
	for(int i = 0 ; i < index ; i++){
			cout<<setw(5)<<arrSt[i].Code<<setw(10)<<arrSt[i].Name<<setw(13)<<arrSt[i].Mathsco<<setw(18)<<arrSt[i].Englishsco<<setw(25)<<arrSt[i].avgScore<<endl; 
	}
}

void DeleteStudent();

//	for(i=0; i<size; i++)
//	{
//		if(arr[i]==del)
//		{
//			for(int j=i; j<(size-1); j++)
//			{
//				arr[j]=arr[j+1];
//			}
//			count++;
//			break;
//		}
//	}

void DeleteStudent(){
		int code;
		cout<<"Delete a Student with Code"<<endl;
		cout<<"Enter the code :"<<endl;
		cin>>code;
		for(int i = 0 ; i < index  ; i ++){
			if(arrSt[i].Code == code){
				for(int j = i ; j < (index); j++){		
					arrSt[j].Code = arrSt[j+1].Code;
					arrSt[j].Name = arrSt[j+1].Name;
					arrSt[j].Mathsco = arrSt[j+1].Mathsco;
					arrSt[j].Englishsco = arrSt[j+1].Englishsco;
					arrSt[j].avgScore = arrSt[j+1].avgScore;	
				}
				break;
			}
		}
}
void SeachStudent();
void SeachStudent(){
		int code;
		cout<<"Search a Student with Code"<<endl;
		cout<<"Enter the code :"<<endl;
		cin>>code;
		for(int i = 0 ; i < index ; i ++){
			if(code == arrSt[i].Code){
				cout<<"Information Of Student "<<endl;
				cout<<"Code :"<<arrSt[i].Code<<endl;
				cout<<"Name :"<<arrSt[i].Name<<endl;
				cout<<"Avg Score :"<<arrSt[i].avgScore<<endl;
			}
		}
}
void EditStudent();
void EditStudent(){
		int code;
		cout<<"Edit a Student with Code"<<endl;
		cout<<"Enter the code :"<<endl;
		cin>>code;
		for(int i = 0 ; i < index ; i ++){
			if(code == arrSt[i].Code){
				
			}
		}
}


int main(){
	int ans;
	while(true){
		//	LOOP : 
		do
		{
			system("CLS");
			cout<<"The program for Get Avg Score of Student"<<endl;
			cout<<"1. New Student"<<endl;
			cout<<"2. Show information of Student "<<endl;
			cout<<"3. Delete a student with code "<<endl;
			cout<<"4. Search a student with code "<<endl;
			cout<<"5. Edit a student with code"<<endl;
			cout<<"6. Exit"<<endl;
			cout<<"Chose 1 - 6 :";
			cin>>ans;
		}while(ans < 1 || ans > 6);
		switch(ans){
			case 1 :
				NewStudent();
				system("PAUSE");
				break;
			case 2 :
				OutputStudent();
				system("PAUSE");
				break;
			case 3 :
				DeleteStudent();
				system("PAUSE");
				break;
			case 4 :
				SeachStudent();
				system("PAUSE");
				break;
			case 5 :
				EditStudent();
				system("PAUSE");
				break;
			case 6 :
				exit(1);
				break;
			default:
			//	goto LOOP;
				break;
		}
	}
	return 0;	
}


/* C++ Program - Delete Element from Array */
		
//#include<iostream>
//using namespace std;
//int main()
//{
//	int arr[50], size, i, del, count=0;
//	cout<<"Enter array size : ";
//	cin>>size;
//	cout<<"Enter array elements : ";
//	for(i=0; i<size; i++)
//	{
//		cin>>arr[i];
//	}
//	cout<<"Enter element to be delete : ";
//	cin>>del;
//	for(i=0; i<size; i++)
//	{
//		if(arr[i]==del)
//		{
//			for(int j=i; j<(size-1); j++)
//			{
//				arr[j]=arr[j+1];
//			}
//			count++;
//			break;
//		}
//	}
//	if(count==0)
//	{
//		cout<<"Element not found..!!";
//	}
//	else
//	{
//		cout<<"Element deleted successfully..!!\n";
//		cout<<"Now the new array is :\n";
//		for(i=0; i<(size-1); i++)
//		{
//			cout<<arr[i]<<" ";
//		}
//	}
//}
