//	int size = sizeof(book)/sizeof(book[0]) ;
//	sizeof(book)/sizeof(*book) ;
//	cout<<size;
#include<iostream>
#include<iomanip>
#include<cstdlib>
using namespace std;
class Book {
	private :
		int code;
		string name;
		int num_page;
	public :
		Book();
		Book(int c , string s , int p);
		void setCode(int c);
		int getCode();
		void setName(string n);
		string getName();
		void setPage(int p);
		int getPage();
		void Input();
		void Output();
		~Book();
		
};
Book :: Book(){
	code = 0;
	name = "";
	num_page = 0;
}
Book :: Book(int c , string n , int p){
	code = c;
	name = n;
	num_page = p;
}

void Book :: setCode(int c){
	code = c;
}
int Book :: getCode(){
	return code;
}
void Book :: setName(string n){
	name = n;
}
string Book :: getName(){
	return  name;
}
void Book :: setPage(int p){
	num_page = p;
}
int Book :: getPage(){
	return num_page;
}
void getMaxMinPage();
void getMaxPage(Book book[] , int size){
	int max = 0 , min=book[0].getPage() , tmpa , tmpi;
	cout<<" \nGet Max Page "<<endl;
	for(int i = 0 ; i < size  ;i++ ){
		if(max < book[i].getPage()){
			max =  book[i].getPage();
			tmpa = i;
		}
		if(min > book[i].getPage()){
			min =  book[i].getPage();
			tmpi = i;
		}
	}
	cout<<"Max"<<endl;
	book[tmpa].Output();
	cout<<"\nMin"<<endl;	
	book[tmpi].Output();
}
void SearchBook(Book book[] , int size);
void SearchBook(Book book[] , int size){
	
	int code;
	cout<<"\nEnter the code for Search :";
	cin>>code;
	for(int i = 0 ; i < size ; i++){
		if(code == book[i].getCode()){
			book[i].Output();
		}
	}

}

int main(){
	
	while(true){
		int choose;
	LOOP:do{
			cout<<"The program for Book Store"<<endl;
			cout<<"1.New Book "<<endl;
			cout<<"2.Show All Book"<<endl;
			cout<<"3.Search Book with code "<<endl;
			cout<<"4.Delete a Book with code "<<endl;
			cout<<"5.Edit with code "<<endl;
			cout<<"6.Get Max Page with code "<<endl;
			cout<<"7.Exit"<<endl;
			cout<<"Choose (1 - 7>"<<endl;
			cin>>choose;
		}while(choose <1 || choose > 7)
		switch(choose){
			case 1 :
				int n;
				cout<<"\nEnter the numbers of element you need storage : ";
				cin>>n;
				Book book[n];
				for(int i = 0 ; i < n ; i++){
					book[i].Input();
				}
				break;
			case 2 :
				break;
			case 3 :
				break;
			case 4 :
				break;
			case 5 :
				break;
			case 6 :
				break;
			case 7 :
				break;
			default :
				goto LOOP;
				break;
				
			
				
		}
		
	}
	
	


	for(int i = 0 ; i < n ; i++){
		book[i].Output();
	} 
	
	getMaxPage(book , n);
	
	SearchBook(book , n);
	
	
	return 0;
}

void Book :: Input(){
	cout<<"\nCode :";
	cin>>code;
	fflush(stdin);
	cout<<"\nName :";
	getline(cin , name);
	cout<<"\nNumbets of Page :";
	cin>>num_page;
}
void Book :: Output(){
	cout<<"\nCode :"<<code;
	cout<<"\nName :"<<name;
	cout<<"\nNumbers ofPage :"<<num_page;
}

Book :: ~Book(){
//	cout<<"\nDestructor of Book "<<endl;
}

//void Book_Input(){
//	int code , page ;
//	string name ;
//	Book bI;
//	cout<<"\nCode :";
//	cin>>code;
//	bI.setCode(code);
//	cout<<"\nName :";
//	getline(cin , name);
//	bI.setName(name);
//	cout<<"\nNumbers of page :";
//	cin>>page;
//}
//void Book_Output(){
//}
