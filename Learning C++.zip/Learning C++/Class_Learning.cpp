/*
nen truyen kieu tham chieu
:: toan tu phan giai pham vi de xac dinh xem no thuoc class nao
*/
#include<iostream>
#include<cstdlib>
using namespace std;

class Student {
	//khong chi dinh pham vi thi mac dinh la private 
	// tinh che giau thong tin (viet ham set get) 
	private :
		int code ;
		string name;
		string school;
		double score;
	public:
		Student(); //ham tao khong doi so kiem tra dieu kien truyen vao hop le
		Student(int ic , string  sn , string ss , double ds); //kiem tra dieu kien dau vao
		void setCode(int code); // cai dat gia tri cho code
		int getCode(); // tra ve gia tri hien tai cua code
		void setName(string name);
		string getName();
		void setSchool(string school);
		string getSchool();
		void setScore(double score);
		double getScore();
		void Input();
		void Output();
		~Student(); //ham huy dc goi truoc khi pha huy doi tuong cua lop
};

class ClassRoom{
	private :
		Student st[100];
};



//Student arrSt1[100];
//int index = 0; 
void Output(Student st[] );
void Output(Student st[] ){
	int size = 100 ;
	for(int i = 0 ; i < size ; i++ ){
		cout<<"\nCode :"<<st[i].getCode();
		cout<<"\nName :"<<st[i].getName();
		cout<<"\nSchool :"<<st[i].getSchool();
		cout<<"\nScore :"<<st[i].getScore();	
	}
	
}

int main(){
//	int id = 1;
//	string Name[] = {"Viet" , "Nam" , "Minh" , "Anh" , "Quan"};
//	string School[] = {"TLU" , "HUST" , "UET" , "NEU" , "BHA"};
//	double Score ;
//	const int N = 10 ;
//	cout<<"Enter the number of ST:";
//	cin>>N;
//	Student arrSt[N];
//	for(int i = 0 ; i < N ; i++){
//		arrSt[i].setCode(id++);
//		arrSt[i].setName(Name[rand() %  5]);
//		arrSt[i].setSchool(School[rand() %  5]);
//		arrSt[i].setScore(rand() %  10);
//	}	
//	Output(arrSt);
//	
	
//	Student st;
//	st.Input();
//	st.Output();
	Student st(5 , "Viet" , "TLU" , 9.0);
	st.Output();
	return 0;
}

void Student :: setCode(int c){
	code = c;
}
int Student :: getCode(){
	return code;
}

void Student :: setName(string n){
	name = n;
}
string Student :: getName(){
	return name;
}

void Student :: setSchool(string s){
	school = s ;
}
string Student :: getSchool(){
	return school;
}

void Student :: setScore(double s){
	score = s;
}
double Student :: getScore(){
	return score;
}

void Student :: Input(){
//	cout<<"\nEnter the code :";
//	cin>>code;
//	cout<<"\nEnter the name :";
//	fflush(stdin); getline(cin , name);
//	cout<<"\nEnter the Score :";
//	cin>>score;
} 


void Student :: Output(){
	cout<<"\nCode :"<<code<<endl;
	cout<<"\nName:"<<name<<endl;
	cout<<"\nScore :"<<score<<endl;
}

Student :: Student(){
	code = 0;
	name = "";
	school = "";
	score = 0.0;
}
Student :: Student(int ic , string  sn , string ss , double ds){
	code = ic;
	name = sn;
	school = ss;
	score = ds;
}
