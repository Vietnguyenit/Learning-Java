/*  
 * Chuong trinh minh hoa Cau truc va vector
 * 
 * Author: Nguyen-Tuan-Thanh Le 
 * Phien ban 1 - Date: 28/07/2017
 *
 */
 
#include<iostream>
#include<vector>
using namespace std;

struct Student
{
    string strMaSV;
    string strHotenSV;
    string strLop;
    double dDiem;
};

// Khai bao ham
void themSinhVien(vector<Student> &dsSinhVien); // them mot sinh vien vao danh sach
void inThongTinSV(Student aStudent); // in thong tin cua mot sinh vien
void lietKeDSSV(vector<Student> dsSinhVien);
void xoaSinhVien(string maSV, vector<Student> &dsSinhVien);

int main()
{
	vector<Student> danhSachSV;
	int chon = 0;
	do
	{
		system("cls");
		cout <<"\n -------- MENU CHUONG TRINH ---------------";
		cout <<"\n 1. Them sinh vien moi vao danh sach";
	    cout <<"\n 2. Xoa 1 sinh vien khoi danh sach";
	    cout <<"\n 3. Tim kiem sinh vien theo ma sinh vien";
	    cout <<"\n 4. Liet ke dan sach sinh vien theo lop";
	    cout <<"\n 5. Liet ke danh sach tat ca cac sinh vien";
	    cout <<"\n 6. Thoat!";
	    cout <<"\n -----------------------------------------";
		cout <<"\n Lua chon cua ban (1 -> 6): ";	
		cin>>chon; 
		switch (chon)
		{
			case 1 :
    	          		{    	     
				  	themSinhVien(danhSachSV);
				  	system("pause");
    	          			break;
				  }
			case 2 :
    	          		{ 
				  	cout <<"\n -----------------------------------------";
		    	  		string maSV;
		    	  		cout <<"\n Nhap ma sinh vien can xoa: ";cin>>maSV;
					     	     
				  	xoaSinhVien(maSV, danhSachSV);
				  	//system("pause");
    	          			break;
				  }	 
			case 3:
				{
					break;
				}
			case 4:
				{
					break;
				}		   	  
			case 5 :
    	          		{    	     
				  	lietKeDSSV(danhSachSV);
				  	system("pause");
    	          			break;
				  }	  
			default: break;
		}
		
	} while (chon!=6);
	return 0;
}

void themSinhVien(vector<Student> &dsSinhVien)
{
    cout <<"\n -----------------------------------------";    
	 	
  	Student aStudent;
  	cin.ignore();
  	cout<<"\n Nhap ma sinh vien : ";getline(cin, aStudent.strMaSV);  	
  	cout<<" Nhap ten sinh vien: "; getline(cin, aStudent.strHotenSV);	
	cout<<" Nhap lop cua sinh vien: ";getline(cin, aStudent.strLop);
	cout<<" Nhap diem sinh vien: ";cin>>aStudent.dDiem;

	dsSinhVien.push_back(aStudent);  										
}

void inThongTinSV(Student aStudent)
{
	cout <<"   Ten sinh vien: "<<aStudent.strHotenSV;
	cout <<"\n   Ma sinh vien: "<<aStudent.strMaSV;
	cout <<"\n   Diem cua sinh vien: "<<aStudent.dDiem;
	cout <<"\n   Lop cua sinh vien: "<<aStudent.strLop << "\n\n";
}

void lietKeDSSV(vector<Student> dsSinhVien)
{
	cout <<"\n -----------------------------------------";
 	cout <<"\n Danh sach hien co gom " << dsSinhVien.size() << " sinh vien, nhu sau:";
 	for (int i=0; i<dsSinhVien.size(); i++)
 	{
 		cout <<"\n  -- Sinh vien thu " << i+1 << " --\n";
 		inThongTinSV(dsSinhVien[i]);
	}
}

void xoaSinhVien(string maSV, vector<Student> &dsSinhVien)
{	
	if (dsSinhVien.size() == 0)
	{
		cout << "Danh sach co 0 sinh vien !\n";
	} 
	else 
	{
		int pos = -1;
	   	for (int i = 0; i < dsSinhVien.size(); i++)
	   	{
	   		if (dsSinhVien[i].strMaSV == maSV)
	   		{
	   			pos = i;
	   			break;
			}
		}
		
		if (pos > -1)
		{
			dsSinhVien.erase(dsSinhVien.begin() + pos);
		}	
	}	
}
