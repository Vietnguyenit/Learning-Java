#include<iostream>
using namespace std;

void FindAdd(int *p);
void FindAdd(int *p){
	for(int i = 0 ; i < 10 ; i++){
		cout<<*(p+i)<<" ";
	}
}
int main(){
	int *p;
	int arr[10]  = {0,5,2,3,4,5,6,7,8,9};
	p = arr ;
	FindAdd(p);	
	return 0;
}
