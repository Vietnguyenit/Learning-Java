#include<iostream>
using namespace std;
struct Person{
	
};
struct Student {
	string code;
	string name;
	string hometown;
	double score;
	Person p;
};

// fflush(stdin) Clear the cache
// should use referrnces var to function  , if save memory born

int main(){
	Student st;
	string code ;
	string name , hometown;
	double score;
	
	//code = st.code = 1;
	getline(cin, st.code);
	name = st.name = "Viet";
	hometown = st.hometown = "HaNoi";
	score = st.score = 9.1;
	cout<<"Code :"<<st.code<<"\nName :"<<name<<"\nHomwtown :"<<hometown<<"\nScore :"<<score<<endl;
	return 0;
}
