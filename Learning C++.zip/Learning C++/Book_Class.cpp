#include<iostream>
#include<iomanip>
#include<cstdlib>
using namespace std;

class Book {
	private :
		int code;
		string name;
		int num_page;
	public :
		Book();
		Book(int c , string s , int p);
		void setCode(int c);
		int getCode();
		void setName(string n);
		string getName();
		void setPage(int p);
		int getPage();
		void Input();
		void Output();
		~Book();
};
Book :: Book(){
	code = 0;
	name = "";
	num_page = 0;
}
Book :: Book(int c , string n , int p){
	code = c;
	name = n;
	num_page = p;
}

void Book :: setCode(int c){
	code = c;
}
int Book :: getCode(){
	return code;
}
void Book :: setName(string n){
	name = n;
}
string Book :: getName(){
	return  name;
}
void Book :: setPage(int p){
	num_page = p;
}
int Book :: getPage(){
	return num_page;
}

int main(){
	Book b1;
	b1.Input();
	b1.Output();
	
	return 0;
}

void Book :: Input(){
	cout<<"\nCode :";
	cin>>code;
	fflush(stdin);
	cout<<"\nName :";
	getline(cin , name);
	cout<<"\nNumbets of Page :";
	cin>>num_page;
}
void Book :: Output(){
	cout<<"\nCode :"<<code;
	cout<<"\nName :"<<name;
	cout<<"\nNumbers ofPage :"<<num_page;
}

Book :: ~Book(){
	cout<<"\nDestructor of Book "<<endl;
}

