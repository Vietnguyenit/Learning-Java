/*
create Student class 
operator overloadding >> , << for Input , Output
operator overloadding == for compare to components
*/
#include<iostream>
#include<cstdlib>
using namespace std;
class Student {
	private :
		int Code;
		string Name;
		string Class;
		double Score;
	public :
		int getCode();
		void setCode(int c);
		string getName();
		void setName(string n);
		string getClass();
		void setClass(string c);
		double getScore();	
		void setScore(double s);
		friend ostream& operator << (ostream& ots , Student& st); // 
		friend istream& operator >> (istream& its , Student& st);
		friend bool operator == (Student& st1 , Student& st2);
		friend Student operator + (Student& st1 , Student& st2);
		friend Student operator - (Student& st1 , Student& st2);
//		friend Student operator * (Student& st1 , Student& st2);
//		friend Student operator / (Student& st1 , Student& st2);
//		friend Student operator ++ (Student& st1 , Student& st2);
//		friend Student operator -- (Student& st1 , Student& st2);
};

int main(){
	Student st1 , st2 , st3 ;
	
//	st1.setCode(2);
//	st1.setName("Viet");
//	st1.setClass("TH1");
//	st1.setScore(9.2);
//	st2.setCode(1);
//	st2.setName("Viet");
//	st2.setClass("TH1");
//	st2.setScore(9.2);

	cout<<"Enter the information"<<endl;
	cin>>st1;
	cin>>st2;
	cout<<"Information of Student "<<endl;
	cout<<st1;
	cout<<st2;

	
	if(st1 == st2){
		cout<<"true"<<endl;
	}else{
		cout<<"False"<<endl;
	}
	
	st3 = st1+st2 ;
	cout<<st3;
	
	st3 = st1 - st2 ;
	cout<<st3;
	
	
	return 0;
}

int Student :: getCode(){
	return Code;
}
void Student :: setCode(int c){
	Code = c;
}
string Student :: getName(){
	return Name;
}
void Student :: setName(string n){
	Name = n;
}
void Student :: setClass(string c){
	Class = c;
}
string Student :: getClass(){
	return Class;
}
void Student :: setScore(double s){
	Score = s;
}

double Student :: getScore(){
	return Score;
}

ostream& operator << (ostream& ots , Student& st){
	ots<<"Code :"<<st.getCode()<<endl;
	ots<<"Name :"<<st.getName()<<endl;
	ots<<"Class :"<<st.getClass()<<endl;
	ots<<"Score :"<<st.getScore()<<endl;	
	return ots;
}
istream& operator >> (istream& its , Student& st){
	int icode;
	string sname , sclass ;
	double dscore;
	cout<<"\nEnter the code :";
	its>>icode;
	st.setCode(icode);
	cout<<"\nEnter the name :";
	its>>sname;
	st.setName(sname);
	cout<<"\nEnter the class :";
	its>>sclass;
	st.setClass(sclass);
	cout<<"\nEnter the score :";
	its>>dscore;
	st.setScore(dscore);
	return its; 
}
bool operator == (Student& st1 , Student& st2){
	return ( (st1.getCode() == st2.getCode()) && (st1.getName() == st2.getName()) && (st1.getScore() == st2.getScore()) );
}
Student operator + (Student& st1 , Student& st2){
//	int Code = st1.getCode() + st2.getCode();
//	string name = st1.getName() + st2.getName();
//	string sclass = st1.getClass() + st2.getClass();
//	double score  = st1.getScore() + st2.getScore();
//	return Student(Code , name , sclass , score);

	Student st;
	st.setCode(st1.getCode() + st2.getCode());
	st.setName(st1.getName() + st2.getName());
	st.setClass(st1.getClass() + st2.getClass());
	st.setScore(st1.getScore() + st2.getScore());	
	return st;
}

Student operator - (Student& st1 , Student& st2){
	Student st ;
	st.setCode(st1.getCode() - st2.getCode());
//	st.setName(st1.getName() - st2.getName()); // string 
//	st.setClass(st1.getClass() - st2.getClass()); // string
	st.setScore(st1.getScore() - st2.getScore());	
	return st;
	
}

Student operator * (Student& st1 , Student& st2){
	
}

Student operator / (Student& st1 , Student& st2){
	
}

//Student operator ++ (Student& st1 , Student& st2){
//	
//}
//
//Student operator -- (Student& st1 , Student& st2){
//	
//}
