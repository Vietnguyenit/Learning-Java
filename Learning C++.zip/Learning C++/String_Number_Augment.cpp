//The program for show a String to sort augment
#include<iostream>
#include<cstring>
using namespace std;
int main(){
//	string name = "Nguyen Tien Viet";
//	string hometown = "Duong Khe ";
//	string arrName1[20] = "456782345";
//	char arrName[6] = {'1', '2', '3', '4', '5', '\0'};
//	for(int i = 0 ; i < 6 ; i++){
//		cout<<arrName[i]<<" ";
//	}
	
	int a = 10;
	double b ;
	double c = 9.7 ;
	b = (double)a;
	cout<<b;
	
	int d = (int)c;
	cout<<d;
	
	char a1 = '4';
	int b1 = (int)a1;
	cout<<b1;
	
	
		 
	
//	cout<<name.size();
//	cout<<hometown.length();
	
	return 0;
}
