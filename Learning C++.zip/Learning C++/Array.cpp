#include<iostream>
#include<iomanip>
using namespace std;
int main(){
//	int a[] = {1 , 0 , 9 , 3 , 5, 2, 6 , 7};
//	cout<<"Array "<<endl;
//	for(int i = 0 ; i < 8 ; i ++){
//		cout<<a[i]<<"   ";
//	}
//	
//	int tmp;
//	for(int i = 0 ; i < 8 ; i++){
//		for(int j = i + 1 ; j < 8 ; j++){
//			if(a[i] > a[j])	{
//				tmp = a[i] ; 
//				a[i] = a[j] ; 
//				a[j] = tmp;
//			}
//		}
//	}
//	
//	cout<<"\nArray "<<endl;
//	for(int i = 0 ; i < 8 ; i ++){
//		cout<<a[i]<<"   ";
//	}

	int a[3][2]= { {4 , 3},  {23 , 8}, {9 , 8} };
	for(int i = 0 ; i < 3 ; i ++){
		for(int j = 0 ; j < 2 ; j ++){
			cout<<a[i][j];
		}	
	}
	return 0;
}
