//The program for Calculate Area a Triagle 
#include<iostream>
#include<cmath>
using namespace std;
double Perimeter(double a , double b, double c);
double Cal_Area(double a , double b , double c);
void Input_Output();

int main(){
	string ans ;
	do{
		Input_Output();
		cout<<"Do you wana continue ?? (y) :";
		getline(cin , ans);	
	}while(ans == "y");
	
	return 0;
}

double Perimeter(double a , double b, double c){
	double Per = 0 ;
	Per = ( a + b + c) / 2 ;
	return Per;
}

double Cal_Area(double a , double b , double c){
	double Area = 0 ;
	double P = Perimeter(a , b , c);
	Area = sqrt(P*(P-a)*(P-b)*(P-c));
	return Area;
}

void Input_Output(){
	double a , b , c ;
	string ans ;
	do{
		cout<<"The program for Calulator Triagle area "<<endl;
		cout<<"Enter the 3 edge :"; cin >>a >>b >>c;
		if((a+b > c) && (b+c > a) && (c+a >b) && a > 0 && b > 0 && c > 0 ){
			double Area ;
			Area = 	Cal_Area(a , b , c);
			cout<<"Area a Triagle :"<<Area<<endl;
		} else{
			cout<<"You Must enter with condition : (a+b > c) && (b+c > a)&& (c+a >b) && a , b , c >0)"<<endl;
		}
	getline(cin , ans);	
	}while(ans == "y");
		
}

