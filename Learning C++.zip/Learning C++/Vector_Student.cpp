#include<iostream>
#include<vector>
using namespace std;

struct Student {
	int Code ;
	string Name;
	string Class;
	double Score;
};

void AddNewSt(vector<Student> &st , int size);
void ShowAllSt(vector<Student> st);
void DeleteSt(vector<Student> st);
void SearchSt(vector<Student> st);
void ListOfClassSt(vector<Student> st);
int main(){
	vector<Student> vtst;
	int choose;
	while(true){
			do{
			system("CLS");
			cout<<"1.New Student "<<endl;
			cout<<"2.Show all Student "<<endl;
			cout<<"3.Search with code "<<endl;
			cout<<"4.Show list with class"<<endl;
			cout<<"5.Delete Student "<<endl;
			cout<<"6.Exit"<<endl;
			cout<<"Choose (1 - 6) : ";
			cin>>choose;
		}while(choose < 1 || choose > 6);	
		switch (choose){
			case 1:
				int size;
				cout<<"How many student you wana add : ";
				cin>>size;
				AddNewSt(vtst , size);
				system("\nPAUSE");
				break;
			case 2:
				ShowAllSt(vtst);
				system("\nPAUSE");
				break;
			case 3:
				SearchSt(vtst);
				system("\nPAUSE");
				break;
			case 4:
				ListOfClassSt(vtst);
				system("\nPAUSE");
				break;
			case 5:
				DeleteSt(vtst);
				system("\nPAUSE");
				break;
			case 6:
				exit(1);
				break;
			default :
				break;
		}	
	}
	return 0;
}

void AddNewSt(vector<Student> &vtst , int size){
	for(int i = 0 ; i < size ; i ++){
		Student st;
		cout<<"\nEnter the code:";
		cin>>st.Code;
		cin.ignore();
		cout<<"\nEnter the name :";
		getline(cin , st.Name);
		cout<<"\nEnter the class :";
		getline(cin , st.Class);
		cout<<"\nEnter the Score  :";
		cin>>st.Score;
		
		vtst.push_back(st);	
	}
}
void ShowAllSt(vector<Student> vtst){
	for(int i = 0 ; i < vtst.size() ; i++){
		cout<<"\nCode of Student  :"<<vtst[i].Code;
		cout<<"\nName of Student  :"<<vtst[i].Name;
		cout<<"\nClass of Student :"<<vtst[i].Class;
		cout<<"\nScore of Student :"<<vtst[i].Score<<endl;
	}	
}
void DeleteSt(vector<Student> vtst){
	int code , tmpvt;
	cout<<"The Code Do you wana find : " ;
	cin>>code;
	bool check = false;
	for(int i = 0 ; i < vtst.size() ; i++ ){
		if(code == vtst[i].Code){
			check = true;
			tmpvt = i ;
			break;
		}else{
			cout<<"Not found"<<endl;
		}
	}
	if(check){
		vtst.erase(vtst.begin() + tmpvt);
		cout<<"Delete Successfully"<<endl;
	}
	
	
}
void SearchSt(vector<Student> vtst){
		int code , tmpvt;
		cout<<"The Code Do you wana find : " ;
		cin>>code;
		bool check = false;
		for(int i = 0 ; i < vtst.size() ; i++ ){
			if(code == vtst[i].Code){
				check = true;
				tmpvt = i ;
				break;
			}else{
				cout<<"Not found"<<endl;
			}
		}
		if(check){
			cout<<"\nCode of Student  :"<<vtst[tmpvt].Code;
			cout<<"\nName of Student  :"<<vtst[tmpvt].Name;
			cout<<"\nClass of Student :"<<vtst[tmpvt].Class;
			cout<<"\nScore of Student :"<<vtst[tmpvt].Score<<endl;
		}	
}

void ListOfClassSt(vector<Student> vtst){
	string Class;
	int tmpvt;
	cout<<"The list of class you wana view :";	
	getline(cin , Class);
	bool check = false;
	for(int i = 0 ; i < vtst.size() ; i++ ){
		if(Class == vtst[i].Class){
			check = true;
			tmpvt = i ;
			break;
		}else{
			cout<<"Not found"<<endl;
		}
	}
	if(check){
		vtst.erase(vtst.begin() + tmpvt);
		cout<<"Delete Successfully"<<endl;
	}
}

