#include<iostream>
#include<vector>
using namespace std;

struct Student {
	int Code ;
	string Name;
	string Class;
	double Score;
};
//them moi sinh vien
void AddNewSt(vector<Student> &st , int size);
// hien thi tat ca sinh vien co trong danh sach
void ShowAllSt(vector<Student> st);
// xoa sinh vien theo ma
void DeleteSt(vector<Student> &st);
//tim kiem sinh vien theo ma
void SearchSt(vector<Student> st);
// hien thi sinh vien cung lop (nhap vap lop)
void ListOfClassSt(vector<Student> st);

int main(){
	vector<Student> vtst;
	int choose;
	while(true){
			do{
			system("CLS");
			cout<<"1.New Student "<<endl;
			cout<<"2.Show all Student "<<endl;
			cout<<"3.Search by code "<<endl;
			cout<<"4.Show list by class"<<endl;
			cout<<"5.Delete Student "<<endl;
			cout<<"6.Exit"<<endl;
			cout<<"Choose (1 - 6) : ";
			cin>>choose;
		}while(choose < 1 || choose > 6);	
		switch (choose){
			case 1:
				int size;
				cout<<"How many student you wana add : ";
				cin>>size;
				AddNewSt(vtst , size);
				system("\nPAUSE");
				break;
			case 2:
				ShowAllSt(vtst);
				system("\nPAUSE");
				break;
			case 3:
				SearchSt(vtst);
				system("\nPAUSE");
				break;
			case 4:
				ListOfClassSt(vtst);
				system("\nPAUSE");
				break;
			case 5:
				DeleteSt(vtst);
				system("\nPAUSE");
				break;
			case 6:
				exit(1);
				break;
			default :
				break;
		}	
	}
	return 0;
}

void AddNewSt(vector<Student> &vtst , int size){
	for(int i = 0 ; i < size ; i ++){
		Student st;
		cout<<"\nEnter the Student : "<<i+1<<endl;
		cout<<"\nEnter the code:";
		cin>>st.Code;
		cin.ignore();
		cout<<"\nEnter the name :";
		getline(cin , st.Name);
		cout<<"\nEnter the class :";
		getline(cin , st.Class);
		cout<<"\nEnter the Score  :";
		cin>>st.Score;
		
		vtst.push_back(st);	
	}
}
void ShowAllSt(vector<Student> vtst){
	cout<<"List of Student"<<endl;
	for(int i = 0 ; i < vtst.size() ; i++){
		cout<<"\nThe student number :"<<i+1<<endl;
		cout<<"\nCode of Student  :"<<vtst[i].Code;
		cout<<"\nName of Student  :"<<vtst[i].Name;
		cout<<"\nClass of Student :"<<vtst[i].Class;
		cout<<"\nScore of Student :"<<vtst[i].Score<<endl;
	}	
}
void DeleteSt(vector<Student> &vtst){
	int code , tmpvt;
	cout<<"The Code Do you wana delete : " ;
	cin>>code;
	bool check = false;
	for(int i = 0 ; i < vtst.size() ; i++ ){
		if(vtst[i].Code == code){
			check = true;
			tmpvt = i ;
			cout<<"a";
			break;
		}
	}
	if(check){
		vtst.erase(vtst.begin() + tmpvt);
		cout<<"Delete Successfully"<<endl;
	}else{
		cout<<"Not found"<<endl;
	}
	
	
}
void SearchSt(vector<Student> vtst){
		int code , tmpvt;
		cout<<"The Code Do you wana find : " ;
		cin>>code;
		bool check = false;
		for(int i = 0 ; i < vtst.size() ; i++ ){
			if(code == vtst[i].Code){
				check = true;
				tmpvt = i ;
				break;
			}
		}
		if(check){
			cout<<"\nCode of Student  :"<<vtst[tmpvt].Code;
			cout<<"\nName of Student  :"<<vtst[tmpvt].Name;
			cout<<"\nClass of Student :"<<vtst[tmpvt].Class;
			cout<<"\nScore of Student :"<<vtst[tmpvt].Score<<endl;
		}
		else{
		cout<<"Not found"<<endl;
		}	
}

void ListOfClassSt(vector<Student> vtst){
	string Class;
	vector<int> vt ;
	cin.ignore();
	cout<<"The list of class you wana view :";	
	getline(cin , Class);
	bool check = false;
	for(int i = 0 ; i < vtst.size() ; i++ ){
		if(vtst[i].Class == Class){
			check = true;
			cout<<i<<endl;
			vt.push_back(i);
		}
	}
	if(check){
			for(int i = 0 ; i < vt.size(); i++){
				//cout<<vt.at(i)<<endl;
				//int a = vt[i];
				//cout<<a<<endl;
				cout<<"\nCode of Student  :"<<vtst[vt[i]].Code;
				cout<<"\nName of Student  :"<<vtst[vt[i]].Name;
				cout<<"\nClass of Student :"<<vtst[vt[i]].Class;
				cout<<"\nScore of Student :"<<vtst[vt[i]].Score<<endl;
			}
			
	}else{
		cout<<"Not found"<<endl;
	}
}

