/* use protected the same private it is usualy for derived  
public use for all 
protected use for inclass and derived class
private use for member var together type
*/
#include<iostream>
#include "Student2.h"
using namespace std;
class Student{
	private :
		double score;
	protected :
		int code ;
	public :
		string name ;
		string school;
		string hometown;
		void Output();
		void setScore(double s);
		double getScore();
		void setCode(int c);
		int getCode();
};
// Derived class
class Student1 : Student {
	public :
		void setCode(int c);
		int getCode();
};
 
void Student :: Output(){
	cout<<"The list of Student "<<endl;
}

void Student :: setCode(int c){
	code = c ;
}
int Student :: getCode(){
	return code;
}

void Student1 :: setCode(int c){
	code = c ;
}
int Student1 :: getCode(){
	return code;
}

void Student :: setScore(double s){
	score = s ;
}
double Student :: getScore(){
	return score;
}

int main(){
	Student2 st2;
	int b = st2.a = 5;
	cout<<b;
	Student st ;
	Student1 st1;
	int code;
	string name , hometown;
	double score;
	st1.setCode(1);
	code = st1.getCode();
	st.setScore(10);
	score = st.getScore();
	st.setCode(4);
	code = st.getCode();
	cout<<code<<" "<<score<<endl;
	return 0;
}
