#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstring>
using namespace std;

int main(){
	vector<int> vt;
	int v , n;
	cout<<"Nhap so phan tu : " ;
	cin>>n;
	for(int i = 0 ; i < n ; i++ ){
		cout<<"Nhap cac phan tu thu "<< i+1 << " : " ;
		cin>>v;
		vt.push_back(v);
	}
	int max = 0 , min = vt[0] ;
	vector<int>::iterator it = vt.begin();  //use iterator 
	while(it != vt.end()){
		if(max < *it){
			max = *it;
		}
		if(min > *it){
			min = *it;		
		}
		it++;
	}
	cout <<"Max : "<<max <<endl;
	cout<<"Min :" <<min<<endl;
	return 0;
}
