#include<iostream>
#include<iomanip>
#include<cstdlib>
using namespace std;

void PrintBooks(struct Book *book);
struct Book{
	int code;
	string name;
	double price;
};

Book book[50];
int index = 0;

void newBook();
void newBook(){
	int b;
	Book bk;
	cout<<"New Book :"<<endl;
	cout<<"Enter the number of books to add :"<<endl;
	cin>>b;
	for(int i = 0 ; i < b ; i++){
		cout<<"Import Book :"<<i+1<<endl;
		cout<<"Code : ";
		cin>>bk.code;
		cin.ignore();
		cout<<"\nName :";
		getline(cin , bk.name);
		cout<<"\nPrice: ";
		cin>>bk.price;
		book[index] = bk;
		index++;		
	}
}
void Output(){
	cout<<setw(5)<<"Code"<<setw(10)<<"Name"<<setw(15)<<"Price"<<endl;
	for(int i = 0 ;  i < index ; i++){
		cout<<setw(5)<<book[i].code<<setw(10)<<book[i].name<<setw(15)<<book[i].price<<endl;
	}
}

int main(){
	
	/*Book b;
	string s;
	cout<<"The program for information of Book "<<endl;
	cout<<"Enter the code : ";
	cin>>b.code;
	cin.ignore();
	cout<<"\nEnter the name :";
	getline(cin , s);
	cout<<"\nEnter the Price : ";
	cin>>b.price;
	PrintBooks(&b);*/
	
	newBook();
	Output();
	
	
	return 0;
}

void PrintBooks(struct Book *book){
	cout<<"\nCode :"<<book->code<<endl;	
	cout<<"\nName :"<<book->name<<endl;
	cout<<"\nPrice :"<<book->price<<endl;
}

