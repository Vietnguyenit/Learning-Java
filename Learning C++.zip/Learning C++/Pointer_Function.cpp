//	a +=b ; swap don't need tmp
//	b = a-b;
//	a = a-b;
#include<iostream>
using namespace std;
void swap(int *x , int *y);
void swap(int *x , int *y){
	int tmp;
	tmp = *x ; 
	*x = *y ; 
	*y = tmp;
}

void swap1(int &x , int &y);
void swap1(int &x , int & y){
	int tmp;
	tmp = x ;
	x = y;
	y = tmp;
}

int main(){
	int a = 10 ; 
	int b = 50;
	cout<<"Before"<<endl<<"a:"<<a<<endl<<"b:"<<b<<endl;
	swap(&a , &b);
	cout<<"After"<<endl<<"a:"<<a<<endl<<"b:"<<b<<endl;
	
	cout<<"Before"<<endl<<"a:"<<a<<endl<<"b:"<<b<<endl;
	swap1(a , b);
	cout<<"After"<<endl<<"a:"<<a<<endl<<"b:"<<b;
	
	int var1 = 10;
int *p;
p = &var1;

cout << "Address of var1 variable: ";
cout << var1  << endl;
cout<<*p<<endl;
	return 0;
}
