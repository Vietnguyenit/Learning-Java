// Operator overloadding is not  member function 
#include<iostream>
#include<cstdlib>
#include<cmath>
using namespace std;
class Fraction{
	private :
		int Num ; // Numerator
		int Den ; //Denominator
	public :
		//
		Fraction();
		Fraction(int n , int d);
		//
		void setNum(int n);
		int getNum();
		
		void setDen(int d);
		int getDen();
		//
		friend Fraction operator + (Fraction &f1 ,Fraction &f2);
		friend Fraction operator - (Fraction &f1 ,Fraction &f2);
		friend Fraction operator * (Fraction &f1 ,Fraction &f2);
		friend Fraction operator / (Fraction &f1 ,Fraction &f2);
		friend bool operator > (Fraction &f1 ,Fraction &f2);
		friend bool operator < (Fraction &f1 ,Fraction &f2);
		friend Fraction operator - (Fraction &f1);
		friend bool operator == (Fraction &f1 ,Fraction &f2);
		friend ostream& operator << (ostream& ost ,Fraction &fo);
		friend istream& operator >> (istream& ist ,Fraction &fi);
		
		// 
		//int UCLN(int a , int b);
		Fraction simplify(Fraction f);
		Fraction standardize(Fraction f);
		

};
int main(){
	Fraction f1 , f2 , f3 ;
	char ans;
	do{
		system("CLS");
		cin>>f1;
		cin>>f2 ;
		cout<<f1;
		cout<<f2;
		
		cout<<"\nAddition"<<endl;
		f3 = f1 + f2 ;
		cout<<f3;
		
		cout<<"\nSubtraction"<<endl;
		f3 = f1 - f2 ;
		cout<<f3;
		
		cout<<"\nMultiplication"<<endl;
		f3 = f1 * f2 ;
		cout<<f3;
		
		cout<<"\nDivision"<<endl;
		f3 = f1 / f2 ;
		cout<<f3;
		
		cout<<"Compare"<<endl;
		
		if(f1 > f2){
			cout<<"f1 > f2"<<endl;
		} else if(f1 < f2){
			cout<<"f1 < f2"<<endl;
		}else if(f1 == f2){
			cout<<"f1 = f2 "<<endl;
		}else{
			cout<<"Can't Compare"<<endl;
		}
		
		cout<<"Standardize "<<endl;
		f3 = -f1 ;
		cout<<f3;
		
		
		cout<<"Do you wana continue (y) : ";
		cin>>ans;
	}while(ans == 'y');
	Fraction f;
	f.UCLN(9 , 27);
	return 0;
}
Fraction :: Fraction(){
	Num = 0;
	Den = 0 ;
}
Fraction :: Fraction (int n , int d){
	Num = n;
	Den = d;
}
void Fraction :: setNum(int n){
	Num = n;
}
int Fraction :: getNum(){
	return Num;
}
void Fraction :: setDen(int d){ 
	Den = d;
}
int Fraction :: getDen(){
	return Den;
}

ostream& operator << (ostream& ost ,Fraction &fo){
	ost<<"Fraction Num :"<<fo.getNum()<<"/"<<fo.getDen()<<endl;
	return ost;
}
istream& operator >> (istream& ist ,Fraction &fi){
	int f , d  ;
	cout<<"Enter the two Fraction" <<endl;
	ist>>f;
	fi.setNum(f);
	cout<<"/" ;
	ist>>d;
	if
	fi.setDen(d);
	return ist;
}

Fraction operator + (Fraction& f1 ,Fraction& f2){
	Fraction fr1;
	fr1.setNum(f1.getNum()* f2.getDen() + f2.getNum()*f1.getDen());
	fr1.setDen(f1.getDen()*f2.getDen());
	return fr1;	
}

Fraction operator - (Fraction& f1 ,Fraction& f2){
	Fraction fr1;
	fr1.setNum(f1.getNum()* f2.getDen() - f2.getNum()*f1.getDen());
	fr1.setDen(f1.getDen()*f2.getDen());
	return fr1;	
}

Fraction operator * (Fraction& f1 ,Fraction& f2){
	Fraction fr1;
	fr1.setNum(f1.getNum()*f2.getNum());
	fr1.setDen(f1.getDen()*f2.getDen());
	return fr1;	
}

Fraction operator / (Fraction &f1 ,Fraction &f2){
	Fraction fr1;
	fr1.setNum(f1.getNum()*f2.getDen());
	fr1.setDen(f1.getDen()*f2.getNum());
	return fr1;	
}
bool operator > (Fraction &f1 ,Fraction &f2){
	return (f1.getNum() * f2.getDen() >  f2.getNum() * f2.getDen());
}
bool operator < (Fraction &f1 ,Fraction &f2){
	return (f1.getNum() * f2.getDen() <  f2.getNum() * f2.getDen() );
}
bool operator == (Fraction &f1 ,Fraction &f2){
	return (f1.getNum() == f2.getNum() && f1.getDen() == f2.getDen());
}
Fraction operator - (Fraction &f){
	if(f.getDen() < 0 ){
		f.setDen(abs(f.getDen()));
		f.setNum(-(f.getNum()));
	}
	return f;
}
Fraction simplify(Fraction f1){	
}
Fraction standardize(Fraction f){
	if(f.getDen() < 0 ){
		f.setDen(abs(f.getDen()));
		f.setNum(-(f.getNum()));
	}
	return f;
}
//int UCLN(int a , int b){
//	vector<int> ucln1;
//	vector<int> ucln2;
//	for(int i = 0 ; i < a ; i++){
//		if(a % i == 0){
//			ucln1.push_back(i);
//		}
//		if(b % i == 0){
//			ucln2.push_back(i);
//		}	
//	}
//	
//	for(int i = 0 ; i < ucln1.size(); i++){
//		cout<<ucln1[i];
//	}
//	for(int i = 0 ; i < ucln2.size(); i++){
//		cout<<ucln2[i];
//	}
//}


