int *a = new int;
// do_something;
delete a; // gi?i ph�ng con tr? a d� c?p ph�t ? tr�n

double *arr = new double[5];
// do_something;
delete[] arr; // gi?i ph�ng m?ng arr d� du?c c?p ph�t ? tr�n
