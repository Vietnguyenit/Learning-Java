#include<iostream>
using namespace std;
int main(){
	int n;
	char tl ;
	do{
		cout<<"Nhap 1 so :"; cin >> n;
		int count = 0;
		for(int t = 2 ; t < n ; t ++){
			for(int i = 1 ; i <= t ; i ++ ){
			if(t % i == 0){
				count++;
			}
			}
			if(count == 2 )
				cout<<"So Nguyen To: "<<t<<endl ;
				count = 0 ;			
		}
		cout<<"TL :";
		cin>>tl;
	}while(tl == 'y');

	return 0;
}
