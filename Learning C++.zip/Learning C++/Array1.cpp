#include<iostream>
using namespace std;
int main(){
	int Max;
	cout<<"Moi nhap so phan tu cua mang :";
	cin>>Max;
	int score[Max];
	cout<<"Moi nhap tung phan tu "<<endl;
	for(int i = 0 ; i < Max ; i++){
		cout<<"a["<<i<<"] = ";
		cin>>score[i];	
	}
	
	for(int i = 0 ; i < Max ; i++){
		cout<<score[i]<<" ";
	}
	int max;
	max = score[0];
	for(int i = 1 ; i < Max ; i++){
			if(max < score[i]){
				max = score[i];
			}
	}
	cout<<"\nPhan tu lon nhat trong mang :"<<max<<endl;
	
	for(int i = 0 ; i < Max ; i++ ){
		int d ;
		d = max - score[i]; 
		cout<<d<<endl;
	}
	return 0;
}
