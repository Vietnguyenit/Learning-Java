#include<iostream>
using namespace std;
class Shape{
	private :
		double length ;
	protected:
		double width ;
	public :
		double hight;
		void setLength(double l);
		double getLength();
};

class Triagle : Shape {
	public :
		void setWidth(double w);
		double getWidth();
};

void Triagle :: setWidth(double w){
	width = w ;
}

double Triagle :: getWidth(){
	return width;
}

void Shape :: setLength(double l){
	length = l;
}
double Shape :: getLength(){
	return length;
}

int main(){
	Shape s;
	double len;
	Triagle t ;
	cout<<"Enter the Length :";
	cin>>len;
	t.setLength(len);
	t.setWidth(len);
	s.setLength(len);
	cout<<"s Length  : "<<s.getLength();
	cout<<"t Width  : "<<s.getWidth();
	cout<<"t Length  : "<<s.getLength();	
	return 0;
}

