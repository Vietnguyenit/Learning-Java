#include<iostream>
#include<stdlib.h>
#include<cmath>
using namespace std;

// Dinh nghia lop Phanso
class Phanso
{
	private:
		int tuso;
		int mauso;
	public:
		Phanso();
		Phanso(int _tuso, int _mauso);
		int getTuso();
		int getMauso();	
		void setTuso(int _tuso);	
		void setMauso(int _mauso);
		
		friend Phanso operator + (Phanso& ps1, Phanso& ps2);
		friend bool operator == (Phanso& ps1, Phanso& ps2);
		friend Phanso operator -(Phanso& ps);
		friend ostream& operator << (ostream& ots, Phanso& ps);
		friend istream& operator >> (istream& its, Phanso& ps);								
};

// Tim uoc chung maximum cua hai so nguyen duong
int uscln(int a, int b);

int main()
{	
//	Phanso ps1, ps2;
//	cout << "Nhap tu so va mau so cua phan so: \n"; cin >> ps1;
//	cout << "Nhap tu so va mau so cua phan so: \n"; cin >> ps2;			
//	
//	Phanso ps3;	
//	ps3 = ps1 + ps2;
//	cout << "\nTinh tong phan so vua nhap: \n"; 
//	cout << ps1 << " + " << ps2 << " = " << ps3;

	Phanso ps1, ps2;
	cin >> ps1; // ps1.input();
	cin >> ps2;
	cout << ps1 << "\n" << ps2 << "\n";
//	Phanso ps3;	
//	ps3 = ps1 + ps2;
//	cout << ps1 << " + " << ps2 << " = " << ps3; // ps3.output()	
	
	cout << "So sanh hai phan so vua nhap vao: \n";
	if (ps1==ps2)
	{
		cout << "Hai phan so bang nhau";
	}
	else 
	{
		cout << "Hai phan so khac nhau";
	}
	//cout << "\nUSCLN: "<< uscln(10,15);
	return 0;
}

istream& operator >> (istream& its, Phanso& ps)
{
	int _tuso, _mauso;	
	its >> _tuso >> _mauso;
	
	ps.setTuso(_tuso);
	ps.setMauso(_mauso);
	
	return its;
}

ostream& operator << (ostream& ots, Phanso& ps)
{
	ots << ps.getTuso() << "/" << ps.getMauso();
//	ots << "Tu so: "<< ps.getTuso() << "\n";
//	ots << "Mau so: "<< ps.getMauso() << "\n";
	return ots;
}

Phanso::Phanso()
{
	tuso = 1;
	mauso = 1;
}

Phanso::Phanso(int _tuso, int _mauso)
{	
	tuso = _tuso;
	mauso = _mauso;
}

int Phanso::getTuso()
{
	return tuso;	
}

int Phanso::getMauso()
{
	return mauso;
}

void Phanso::setTuso(int _tuso)
{
	tuso = _tuso;
}

void Phanso::setMauso(int _mauso)
{
	mauso = _mauso;
}

Phanso operator + (Phanso& ps1, Phanso& ps2)
{
	int _tuso = ps1.getTuso()*ps2.getMauso() + ps2.getTuso()*ps1.getMauso();
	int _mauso = ps1.getMauso()*ps2.getMauso();
	
//	int uc = uscln(_tuso,_mauso);
//	return Phanso(_tuso/uc, _mauso/uc);
	return Phanso(_tuso, _mauso);
}

bool operator == (Phanso& ps1, Phanso& ps2)
{
	float fValue1 = (float) ps1.getTuso()/ps1.getMauso();
	float fValue2 = (float) ps2.getTuso()/ps2.getMauso();
//	cout << fValue1 << " - " << fValue2 << "\n";
	return (fValue1 == fValue2);
}

Phanso operator -(Phanso& ps)
{
	return Phanso(-ps.getTuso(), ps.getMauso());
}

// Tim uoc chung maximum cua hai so nguyen duong
int uscln(int a, int b)
{
	if (a % b == 0)
	{
		return b;
	}
	else
	{
		return uscln(b, a%b);
	}
}
//friend const Money operator -(const Money& amount1, const Money& amount2);
