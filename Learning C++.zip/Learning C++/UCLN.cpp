#include <iostream>
using namespace std;

int UCLN(int a, int b)
{
    while ( a != b)
    {
        if (a > b)
            a = a - b;
        else
            b = b - a;
    }

    return a; // or return b; a = b
}


int BCNN(int a, int b)
{
    int result = UCLN(a, b);
    return a * b / result;
}

int uscln(int a, int b)
{
	if (a % b == 0)
	{
		return b;
	}
	else
	{
		return uscln(b, a%b);
	}
}

int main()
{
    int a, b;
    cout << "a = ";
    cin >> a;

    cout << "b = ";
    cin >> b;

    int result = UCLN(a, b);
    cout << "UCLN : "<<result;

    cout << "\n";

    result = BCNN(a, b);
    cout << "BCNN : " << result << endl;
       system("pause");
}
