#include<iostream>
#include<iomanip>
using namespace std;

void NewStudent();
void Output();

struct Student{
	string code;
	string name ;
	double avgScore;
};

Student st;
void NewStudent(){
	int m;
	cout<<"Enter the number of Student :";
	cin>>m;
	for(int i = 0 ; i < m ; i++){
		cin.ignore();
		cout<<"Enter the student :"<<i<<" ";
		cout<<"Enter the code :";
		getline(cin , st.code);
		cout<<"Enter the name : ";
		getline(cin , st.name);
		cout<<"Enter the AvgScore :";
		cin>>st.avgScore;
	} 
}
void Output(){
	cout<<setw(5)<<st.code<<setw(10)<<st.name<<setw(15)<<st.avgScore<<endl;
}
const int a = 100;
Student st[a];


int main(){
	
	return 0;
}
