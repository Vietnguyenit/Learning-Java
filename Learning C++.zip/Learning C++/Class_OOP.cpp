#include<iostream>
#include<cstring>
#include<vector>
#include<iomanip>
using namespace std;
class Student{
	private:
		char Code[5];
		char Name[30];
		double Score;
	public:
		Student();
		Student(char c[] , char n[] , double s);
		void setCode(char c[]);
		char* getCode();
		void setName(char n[]);
		char* getName();
		void setScore(double s);
		double getScore();
		void Input();
		void Output();
};
int main(){
	vector<Student> st;
	int n , choose;
	char tl , code[30];
	while(true){
	do{
		system("CLS");
		cout<<"1.New Student "<<endl;
		cout<<"2.Show list of Student "<<endl;
		cout<<"3.Search Student with Code "<<endl;
		cout<<"4.Exit"<<endl;
		cout<<"Chose (1-4)"<<endl;
		cin>>choose;
		}while(choose < 1 || choose > 4);
		switch(choose){
			case 1:
				cout<<"The numbers student do you want :";
				cin>>n;				
				for(int i = 0 ; i < n ; i ++){
					Student tmpSt;
					cout<<"Enter student numbers : "<<i+1<<" "<<endl;
					tmpSt.Input();
					st.push_back(tmpSt);
				}
				cout<<"Press the anykey to continue ...";
				system("PAUSE>NULL");
				break;
			case 2 :
				cout<<"The list of Student "<<endl;
				if(st.empty()){
					cout<<"the list null"<<endl;
				}else{
					cout<<setw(5)<<"Code"<<setw(10)<<"Name"<<setw(20)<<"Score"<<endl;
					for(int i = 0 ; i < st.size() ; i++){
						st[i].Output();
					}
				}
				cout<<"Press the anykey to continue ...";
				system("PAUSE>NULL");
				break;
			case 3:
				{
					cin.ignore();
					cout<<"Enter the code :";
					cin.getline(code , 30);
					bool check = false;
					int position = -1 ;
					for(int i = 0 ; i < st.size(); i++){
						if(strcmp(st[i].getCode() , code ) == 0 ){
							check = true;
							position = i;
						}
						if(check){
							cout<<setw(5)<<"Code"<<setw(10)<<"Name"<<setw(20)<<"Score"<<endl;
							cout<<"The information of Student "<<endl;
							st[position].Output();
						}
					}
					cout<<"Press the anykey to continue ...";
					system("PAUSE>NULL");
					break;	
				}
			case 4:
				exit(1);
				break;
			}
		}
	return 0;
}

Student :: Student(){
	strcpy(Code , "");
	strcpy(Name , "");
	Score = 0.0;
}

Student :: Student(char c[] , char n[] , double s){
	strcpy(Code , c);
	strcpy(Name , n);
	Score = s;
}

void Student :: setCode(char c[]){
	strcpy(Code , c);
}

char* Student :: getCode(){
	return Code;
}

void Student :: setName(char n[]){
	strcpy(Name , n);
}

char* Student :: getName(){
	return Name;
}

void Student :: setScore(double s){
	Score = s ;
}

double Student :: getScore(){
	return Score;
}

void Student :: Input(){
	cin.ignore();
	cout<<"Enter the Code :";
	cin.getline(Code , 5);
	cout<<"Enter the Name :";
	cin.getline(Name , 30);
	cout<<"Enter the Score :";
	cin>>Score;
}

void Student :: Output(){
	cout<<setw(5)<<Code<<setw(10)<<Name<<setw(20)<<Score<<endl;
}


