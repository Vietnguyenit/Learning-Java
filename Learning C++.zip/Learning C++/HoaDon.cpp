#include<iostream>
#include "HoaDon.h"
using namespace std;

HoaDon :: HoaDon(){
	giaCa = 1 ;
	soLuong = 1 ;
}
HoaDon :: HoaDon(int sl , double gc){
	giaCa = gc;
	soLuong = sl;
}

double HoaDon :: tongTien(){
	return giaCa * soLuong;
}

void HoaDon :: setGiaCa(double gc){
	giaCa = gc;
}
double HoaDon :: getGiaCa(){
	return giaCa;
}
void HoaDon :: setSoLuong(int sl){
	soLuong = sl ;
}
int HoaDon :: getSoLuong(){
	return soLuong;
}
//
//istream& operator >> (istream& ist, HoaDon & h){
//	int sl ;
//	double gc;
//	cout<<"\nNhap so luong :";
//	ist>>sl ;
//	h.setSoLuong(sl);
//	cout<<"Nhap gia ca : ";
//	ist>>gc;
//	h.setGiaCa(gc);
//	
//	return ist;
//}
//ostream& operator << (ostream& ost , HoaDon h ){
//	ost<<"Gia Ca :"<<h.getGiaCa();
//	ost<<"So Luong :"<<h.getSoLuong();
//	
//	return ost;
//}
