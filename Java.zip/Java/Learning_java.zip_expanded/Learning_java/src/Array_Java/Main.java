package Array_Java;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		//int a[] = new int[5];
		int code ;
		String name;
		double math , english , avg = 10.0;
		Scanner scanner = new Scanner(System.in);
		int n = 0 , m = 0;
		System.out.print("Enter the numbers of array :");
		n = scanner.nextInt();
		Student[] students = new Student[n];
		System.out.print("Enter the number :");
		m = scanner.nextInt();
		for(int i = 0 ; i < m ; i ++) {
			System.out.println("Enter the student : " + i+1 );
			System.out.print("Enter the code :");
			code = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter the name :");
			name = scanner.nextLine();
			System.out.println("Enter the math :");
			math = scanner.nextDouble();
			System.out.println("Enter the english :");
			english = scanner.nextDouble();
			
			students[i] = new Student(code, name, math, english, avg);
			scanner.nextLine();
		}
		
		for(Student s : students) {
			//System.out.println("the code :"+ s.getCode());
			
			System.out.println("the name :"+ s.getName());
			
			System.out.println("the math :"+ s.getMath());
			
			System.out.println("the english :"+ s.getEnglish());
			
			System.out.println("the avg :"+ s.getAvg());
			
		}
		
	}
}
