package Array_Java;

public class Student {
	private int code;
	private String name;
	private double math;
	private double english;
	private double avg;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int code, String name, double math, double english, double avg) {
		super();
		this.code = code;
		this.name = name;
		this.math = math;
		this.english = english;
		this.avg = avg;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMath() {
		return math;
	}

	public void setMath(double math) {
		this.math = math;
	}

	public double getEnglish() {
		return english;
	}

	public void setEnglish(double english) {
		this.english = english;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

}
