package Java_adv;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SetDemo {
	public static void main(String[] args) {
		int arr[] = {4 , 0 , 2, 5, 3 , 9 , 1 , 4 , 6 , 8};
		Set<Integer > set = new HashSet<>();
		for(int i = 0 ; i < arr.length ; i++) {
			set.add(arr[i]);
		}
		System.out.println(set);
		
		//TreeSet<Integer> treeSet = new TreeSet<>(set);
		//System.out.println(treeSet);
		
		SortedSet<String> sortedSet = new TreeSet<>();
		sortedSet.add("Viet");
		sortedSet.add("Big Data");
		sortedSet.add("Hadoop");
		System.out.println(sortedSet);
		
		Iterator< String> iterator = sortedSet.iterator();
		while(iterator.hasNext()) {
			Object element = iterator.next();
			System.out.println(element);
		}
		
		
		
	}
}
