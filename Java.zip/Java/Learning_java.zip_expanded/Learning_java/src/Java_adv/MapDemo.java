package Java_adv;

import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.text.html.parser.Entity;

import java.util.Iterator;

public class MapDemo {
	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<Integer , String>();
		
		map.put(1, "Viet"); // them va key la duy nhat
		map.put(2, "Minh"); // key co the null 
		map.put(3, "Nam"); 
		map.put(1, "Quan"); // ghi de len Viet  
		
		//System.out.println(map.get(1)); //get Key
		
		Set<Integer> set = map.keySet();
		for(Integer i : set) {
			System.out.println(i + " " + map.get(i));
		}
		//map.clear();
		map.remove(1);
//		System.out.println("After Delete:");
//		for(Integer i : set) { // Cach 1
//			System.out.println(i + " " + map.get(i));
//		}
	
//		for(Entry<Integer, String> mEntry  : map.entrySet()  ) { // C 2
//			mEntry.getValue(); 
//			mEntry.getValue();
//			System.out.println(mEntry);
//		}
		
		// co the dung Lop tu tao nhu binh thuong  <Person>
		
		Map<Integer, String> map2 = new TreeMap<Integer , String>(); // cac phan tu dc sap xep tang dan
		map2.put(1, "Math");
		map2.put(2, "History");
		map2.put(5, "English");
		map2.put(4, "Zing");
		map2.put(3, "Post");
		
		//map.remove(1);
		
		for(Entry<Integer, String> sEntry : map2.entrySet()) {
			System.out.println(sEntry.getKey() + " " + sEntry.getValue());
		}
		
		
	}
}
