package Java_adv;

import References.refer;

public class SetLib { // du lieu duy nhat khong nhu list dc lap

	private int code;
	private String name;
	
	public SetLib(int code, String name) {
		super();
		this.code = code;
		this.name = name;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public boolean equals(Object o) {
		return (o instanceof SetLib) ? (((SetLib)o).getCode() == this.getCode()) : false ; // dung thi Exception kieu
	}
	
	@Override
		public int hashCode() {
			return this.code;
		}
}
