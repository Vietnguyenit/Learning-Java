package Java_adv;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
	//FIFO
	//Queue khong dam bao tinh duy nhat 
	public static void main(String[] args) {
		Queue<String> queue = new LinkedList<String>();
		queue.add("A");
		queue.add("C");
		queue.add("B");
		queue.add("T");
		queue.add("K");
		queue.add("N");
		
		Iterator<String>  itr = queue.iterator();
		System.out.println("Before");
		while(itr.hasNext()) {
			String s = itr.next();
			System.out.println(s);
		}
		
		queue.remove(); // xoa phan tu dau
		queue.remove("T");
		System.out.println("After");
		for(String s : queue) {
			System.out.println(s);
		}
		
	}
}
