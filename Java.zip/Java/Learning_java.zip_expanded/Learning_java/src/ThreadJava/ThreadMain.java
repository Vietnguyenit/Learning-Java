package ThreadJava;

public class ThreadMain { // trong 1 thoi diem chi co 1 thread vao duoc "minitor" => 1 vao 2345 waiting
	public static void main(String[] args) {
//		Thread_test t = new Thread_test() {};
//		Thread thread = new Thread(t);
//		Thread_test2 t2 = new Thread_test2();
//		Thread thread2 = new Thread(t2);
//		System.out.println(thread.getName());
//		thread.setPriority(1); //  
//		System.out.println(thread.getPriority());
//		System.out.println(thread.isAlive());
//		try {
//			thread.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		thread.start();
//		thread2.start();
		
		SysThread sysThread = new SysThread();
		Thread thread3 = new Thread(sysThread);
		Thread thread4 = new Thread(sysThread);
		thread3.setName("No ");
		thread4.setName("No ");
		thread3.start();
		thread4.start();
		
		ThreadSys threadSys = new ThreadSys();
		Thread thread5 = new Thread(threadSys);
		Thread thread6 = new Thread(threadSys);
		thread5.setName("Use ");
		thread6.setName("Use ");
		thread5.start();
		thread6.start();
	}
}
