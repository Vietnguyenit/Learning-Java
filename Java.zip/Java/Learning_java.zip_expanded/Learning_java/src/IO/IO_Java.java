package IO;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class IO_Java {

	public static void main(String[] args) throws Exception {
		
		//Read Data

		FileOutputStream fos = new FileOutputStream("S:/workspace/test.txt");
		DataOutputStream dos = new DataOutputStream(fos);
		final int num = 5;
		dos.writeInt(num);
		for(int i = 0 ; i < num ; i++) {
			dos.write(i);
		}
		dos.writeUTF("Viet Nguyen Learning Java Lensson IO");
		dos.writeInt(8);
		dos.flush();
		dos.close();
		
		// Write Data
		
		FileInputStream fis = new FileInputStream("S:/workspace/test.txt");
		DataInputStream dis = new DataInputStream(fis);
		int items = dis.readInt();
		for(int i = 0 ; i < items ; i++) {
			int n = dis.readInt();
			System.out.println(n);
		}
		dis.close();
		
	}
}
