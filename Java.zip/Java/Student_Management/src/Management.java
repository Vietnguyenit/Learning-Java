import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class Management {
	 Scanner scanner = new Scanner(System.in);
	 Student student = new Student() ;
	 int n;
	 ArrayList<Student> arrayList = new ArrayList<Student>();
	public void Input() {
		int stcode ;
		String stname  , stclass ;
		double stscore ;
		System.out.println("How many student do you want ?");
		n = scanner.nextInt();
		for(int i = 0 ; i < n ; i ++) {
			boolean kt = false;
			do {
				System.out.println("Enter the student :" + i );
				System.out.print("Enter The Code :");
				stcode = scanner.nextInt();
				student.setSt_code(stcode);
				for(int j = 0 ; j < arrayList.size() ; j++ ) {
					if(stcode == arrayList.get(j).getSt_code()) {
						kt = true;
						System.out.println("Code Exsisted");
						break;
					}else {
						kt = false;
					}
				}
			} while (kt);
			scanner.nextLine();
			System.out.print("Enter the Name :");
			stname = scanner.nextLine();
			student.setSt_name(stname);
			System.out.print("Enter the Class :");
			stclass = scanner.nextLine();
			student.setSt_class(stclass);
			System.out.print("Enter the Score :");
			stscore = scanner.nextDouble();
			student.setSt_score(stscore);	
			arrayList.add(new Student(stcode, stname, stclass, stscore));
		}
	}
	public void Output() {	
		for(int i = 0 ; i < arrayList.size() ; i ++) {
			System.out.println("Information Of Student ");
			System.out.println("Code : " + arrayList.get(i).getSt_code());
			System.out.println("Name : " + arrayList.get(i).getSt_name());
			System.out.println("Class : " + arrayList.get(i).getSt_class());
			System.out.println("Score : " + arrayList.get(i).getSt_score());
		}	
	}
	
	public void Search() {
		Vector<Integer> vector = new Vector<Integer>() ;
		int code , tmp = 0;
		String name , stclass ;
		System.out.print("Choose Search by Code (1) or Search by Name(2) or Search by Class (3) : ");
		tmp = scanner.nextInt();
		if(tmp == 1 ) {
			System.out.print("Enter the Code :");
			code = scanner.nextInt();
			for(int i = 0 ; i < arrayList.size() ; i++) {
				if(code == arrayList.get(i).getSt_code()) {
					tmp = i ;
					vector.addElement(tmp);
					break;
				}	
			}
		}
		if (tmp == 2) {
			scanner.nextLine();
			System.out.print("Enter the Name :");
			name = scanner.nextLine();
			for(int i = 0 ; i < arrayList.size() ; i++) {
				if(name == arrayList.get(i).getSt_name()) {
					tmp = i ;
					vector.addElement(tmp);
					break;
				}	
			}
		}
		
		if(tmp == 3) {
			scanner.nextLine();
			System.out.print("Enter the Class :");
			stclass = scanner.nextLine();
			for(int i = 0 ; i < arrayList.size() ; i++) {
				if(stclass == arrayList.get(i).getSt_class()) {
					tmp = i ;
					vector.addElement(tmp);
					break;
				}	
			}
		}
		for(int i = 0 ; i < vector.size() ; i ++) {
			System.out.println("Information Of Student ");
			System.out.println("Code : " + arrayList.get(vector.elementAt(i)).getSt_code());
			System.out.println("Name : " + arrayList.get(vector.elementAt(i)).getSt_name());
			System.out.println("Class : " + arrayList.get(vector.elementAt(i)).getSt_class());
			System.out.println("Score : " + arrayList.get(vector.elementAt(i)).getSt_score());
		}	
	}
	
	public void Count() {
		System.out.print("Number of list : "+ arrayList.size());
	}
	
	public void GroupbyClass() {
		Vector<Integer> vector = new Vector<Integer>() ;
		int tmp = 0;
		String stclass;
		scanner.nextLine();
		System.out.print("Enter the Class :");
		stclass = scanner.nextLine();
		for(int i = 0 ; i < arrayList.size() ; i++) {
			if(stclass == arrayList.get(i).getSt_class()) {
				tmp = i ;
				vector.addElement(tmp);
			}	
		}
		for(int i = 0 ; i < vector.size() ; i ++) {
			System.out.println("Information Of Student ");
			System.out.println("Code : " + arrayList.get(vector.elementAt(i)).getSt_code());
			System.out.println("Name : " + arrayList.get(vector.elementAt(i)).getSt_name());
			System.out.println("Class : " + arrayList.get(vector.elementAt(i)).getSt_class());
			System.out.println("Score : " + arrayList.get(vector.elementAt(i)).getSt_score());
		}	
	}
	
	public void MaxMinScore() {
		double min = arrayList.get(0).getSt_score() ;
		double max = arrayList.get(0).getSt_score() ;
		int tmpma = 0 , tmpmi = 0;
		for(int i = 0 ; i < arrayList.size() ; i ++) {	
			if(max < arrayList.get(i).getSt_score()) {
				max = arrayList.get(i).getSt_score();
				tmpma = i ;
			}
			if(min > arrayList.get(i).getSt_score()) {
				min = arrayList.get(i).getSt_score();
				tmpmi = i;
			}
		}
		System.out.println("Max Score :" + arrayList.get(tmpma).getSt_score() );
		System.out.println("Min Score :" + arrayList.get(tmpmi).getSt_score() );
	}
	
	public void Edit() {
		int code , tmp = 0 ;
		String stname, stclass;
		double stscore;
		
		scanner.nextLine();
		System.out.println("Enter the code : ");
		code = scanner.nextInt();
		for(int  i = 0 ; i < arrayList.size() ; i++) {
			if(code == arrayList.get(i).getSt_code()) {
				tmp = i ;
				break;
			}
		}
		System.out.println("Code : " + arrayList.get(tmp).getSt_code());
		scanner.nextLine();
		System.out.print("Enter name :");
		stname = scanner.nextLine();
		System.out.print("Enter class :");
		stclass = scanner.nextLine();
		System.out.print("Enter score :");
		stscore = scanner.nextDouble();

		arrayList.set(tmp, new Student(code ,stname , stclass , stscore ));
	}
	
	public void Delete() {
		int code , tmp = 0;
		scanner.nextLine();
		System.out.println("Enter the code : ");
		code = scanner.nextInt();
		for(int  i = 0 ; i < arrayList.size() ; i++) {
			if(code == arrayList.get(i).getSt_code()) {
				tmp = i ;
				break;
			}
		}
		arrayList.remove(tmp);
	}

	
}
