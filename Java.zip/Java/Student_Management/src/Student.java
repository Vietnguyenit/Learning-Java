public class Student {
	private int st_code;
	private String st_name;
	private String st_class;
	private double st_score;
	
	public Student () {
		this(-1 ,"" , "", -1);
	}
	public Student(int st_code, String st_name, String st_class, double st_score) {
		super();
		this.st_code = st_code;
		this.st_name = st_name;
		this.st_class = st_class;
		this.st_score = st_score;
	}
	public int getSt_code() {
		return st_code;
	}
	public void setSt_code(int st_code) {
		this.st_code = st_code;
	}
	public String getSt_name() {
		return st_name;
	}
	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}
	public String getSt_class() {
		return st_class;
	}
	public void setSt_class(String st_class) {
		this.st_class = st_class;
	}
	public double getSt_score() {
		return st_score;
	}
	public void setSt_score(double st_score) {
		this.st_score = st_score;
	}
}
