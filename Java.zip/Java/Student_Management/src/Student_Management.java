import java.util.Scanner;
public class Student_Management extends Student {
	private static Scanner scanner;

	public static void main(String[] args) {
		Management management = new Management();
		scanner = new Scanner(System.in);
		int ans = 0 ;
		while(true) {
			do {
				System.out.println("The program for Student Management");
				System.out.println("1.New Student");
				System.out.println("2.Edit Student");
				System.out.println("3.Delete Student");
				System.out.println("4.Search Student ");
				System.out.println("5.Show list of Student");
				System.out.println("6.Count numbers of student ");
				System.out.println("7.Group by Class");
				System.out.println("8.Max Min score of list");
				System.out.println("10.Exit");
				
				System.out.println("Choose (1 - 10 )");
				ans = scanner.nextInt();
				switch (ans) {
				case 1:
					management.Input();
					break;
				case 2:
					management.Edit();
					break;
				case 3:
					management.Delete();
					break;
				case 4:
					management.Search();
					break;
				case 5 :
					management.Output();
					break;
				case 6 :
					management.Count();
					break;
				case 7 :
					management.GroupbyClass();
					break;
				case 8 :
					management.MaxMinScore();
					break;
				default:
					break;
				}
			}while(ans < 0 || ans > 10);
		}
	}
}
