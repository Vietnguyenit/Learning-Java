package Note;

public class Inner_class {

	//inner static 
	public static class Kid{ // cho lop khac ke thua binh thuong theo quyen truy cap 
		private int code;
		public String name;
		
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
	}
	
	public  class Person{
		private int code;
		private String name;
	}
	// chi ke thua dc ben trong class ngoai thi khong
	public class Student extends Person{
		
	}
	
	public static void main(String[] args) {
		Kid kid = new Kid();
		kid.code = 1;
		
//		Person person = new Person(); // khong the khai bao chi khi dung static
//		person.code = 1; 
	}
}
