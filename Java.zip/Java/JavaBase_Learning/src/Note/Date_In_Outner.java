package Note;

import java.util.Date;

public class Date_In_Outner {
	class Person{ 
		Student student = new Student();
		public void HeHe() { // chi dung duoc the nay thoi khai bao 1 ham roi dung no
			student.code = 1;
		}
	}
	// Outer class
	class Student{ // must public 
		public String name;
		public int code;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
		
		public void Hello() {
			System.out.println("Hello");
		}
		
	}
	
	
	public static void main(String[] args) {
		Date date = new Date();
		Date date2 = new Date();
		System.out.println(date);
		date.getTime();
		if(date.equals(date2)) {
			System.out.println("True");
		}
		
		
		
	}
}
