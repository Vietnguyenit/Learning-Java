package Note;

public class Note {

	//DATE -- CALENDAR 
	/* Dung Date date = new Date(); lay thoi gian hien tai 
	 * Calendar dar = Calendar.getInstance();
	 * so sanh 2 khoang thoi gian  dung ham equals  
	 */
	
	// OUTER CLASS
	/*
	 * khai bao canh lop da viet , su dung nhu binh thuong va no co the ke thua (trong cung package)
	 * public class a{ must public 
	 * }
	 * public class b{
	 * }
	 */
	
	// INNER  STATIC CLASS 
	/*
	 * public private protected static class A{
	 * } 
	 * main {
	 * 
	 * }
	 */
	
}
