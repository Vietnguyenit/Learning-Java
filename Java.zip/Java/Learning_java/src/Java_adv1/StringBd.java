package Java_adv1;

public class StringBd {
	public static void main(String[] args) {
		StringBuilder stringBuilder = new StringBuilder();
		StringBuffer stringBuffer = new StringBuffer();
		stringBuilder.append("Haha");
		stringBuffer.append(stringBuilder);
		
		String s = stringBuffer.toString();
		System.out.println(s);
		
		
	}

}
