package Register;

public class Register_User {
	private String FirstName;
	private String LastName;
	private String Sex;
	private String Address;
	private int Age;
	private String Email;
	private String Password;
	
	public Register_User() {
		this("","","","",0,"","");
	}
	
	public Register_User(String firstName, String lastName, String sex, String address, int age, String email,String password) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Sex = sex;
		Address = address;
		Age = age;
		Email = email;
		Password = password;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
}
