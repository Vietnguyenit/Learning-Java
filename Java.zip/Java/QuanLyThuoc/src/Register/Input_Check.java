package Register;

import java.util.ArrayList;
import java.util.Scanner;

public class Input_Check extends Register_User {
	String firstName, lastName , Sex , Address , Email , Password ;
	int  Age;
	Scanner scanner = new Scanner(System.in); 
	char ans = 0;
	ArrayList<Register_User> register_Users = new ArrayList<Register_User>();
	public void Input() {
		do {
			System.out.println("Enter the FirstName :");
			setFirstName(lastName);
			firstName = scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter the LastName :");
			setLastName(firstName);
			lastName = scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter the Sex :");
			Sex = scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter the Address:");
			Address = scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter the Age :");
			Age = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter the Email :");
			Email= scanner.nextLine();
			scanner.nextLine();
			System.out.println("Enter the Password :");
			Password = scanner.nextLine();
			register_Users.add(new Register_User(firstName , lastName ,Sex , Address, Age ,Email, Password ));
			System.out.println("Continue:");
			ans = scanner.next().charAt(0);	
		} while (ans == 'y');	
	}
	public void Check() {
		
	}
	
	 public void Output() {
		for(Register_User r : register_Users) {
			System.out.println("FirstName :"+r.getFirstName());
			System.out.println("LasrName :"+r.getLastName());
			System.out.println("Sex :"+r.getSex());
			System.out.println("Address :"+r.getAddress());
			System.out.println("Age :"+r.getAge());
			System.out.println("Email :"+r.getEmail());
			System.out.println("Password :"+r.getPassword());
		}
	}
}
