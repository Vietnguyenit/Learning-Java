package Controller;

import Register.Input_Check;

public class Main_Controller {
	public static void main(String[] args) {
		Input_Check input_Check = new Input_Check();
		input_Check.Input();
		input_Check.Output();
	}
	
	
}
